package com.computer.constants;

/**
 * @author DELL
 */
public class ComputerPortletKeys {

	public static final String COMPUTER =
		"com_computer_ComputerPortlet";

}