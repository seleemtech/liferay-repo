package com.computer.portlet;

import com.computer.constants.ComputerPortletKeys;
import com.computerservice.model.Computer;
import com.computerservice.service.ComputerLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author DELL
 */
@Component(
	immediate = true,

	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Computer",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + ComputerPortletKeys.COMPUTER,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class ComputerPortlet extends MVCPortlet {
	@Override
		public void render(RenderRequest renderRequest, RenderResponse renderResponse)
				throws IOException, PortletException {
		String computerId=ParamUtil.getString(renderRequest, "computerId");
		List<Computer> clist=ComputerLocalServiceUtil.getComputers(-1,-1);
		renderRequest.setAttribute("computerId", computerId);
		renderRequest.setAttribute("clist", clist);
		
		if(computerId!=null)
		{
			Computer computer=null;
			try
			{
				computer=ComputerLocalServiceUtil.getComputer(Long.valueOf(computerId));
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			renderRequest.setAttribute("computer", computer);
		}
		super.render(renderRequest, renderResponse);
		}
	@ProcessAction(name="addcomputer")
	public void addcomputer(ActionRequest actionRequest,ActionResponse actionResponse) throws PortalException
	{		System.out.println("methoed is calling");

		long computerId =ParamUtil.getLong(actionRequest, "computerId");
		String computerName=ParamUtil.getString(actionRequest, "computerName");
		String computerParts=ParamUtil.getString(actionRequest, "computerParts");
		
		Computer computer=null;
		if(computerId>0)
		{
			computer =ComputerLocalServiceUtil.getComputer(computerId);
			computer.setComputerId(computerId);
			computer.setComputerName(computerName);
			computer.setComputerParts(computerParts);
			ComputerLocalServiceUtil.updateComputer(computer);
			
		}
		else
		{
			computer=ComputerLocalServiceUtil.createComputer(computerId);
			computer.setComputerId(computerId);
			computer.setComputerName(computerName);
			computer.setComputerParts(computerParts);
			ComputerLocalServiceUtil.addComputer(computer);
		}
	}
	@ProcessAction(name="delete")
	public void delete(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException
	{
		long computerId =ParamUtil.getLong(actionRequest, "computerId");
		ComputerLocalServiceUtil.deleteComputer(computerId);
	}
}