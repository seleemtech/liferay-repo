/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.computerservice.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Computer}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Computer
 * @generated
 */
public class ComputerWrapper
	extends BaseModelWrapper<Computer>
	implements Computer, ModelWrapper<Computer> {

	public ComputerWrapper(Computer computer) {
		super(computer);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("computerId", getComputerId());
		attributes.put("computerName", getComputerName());
		attributes.put("computerParts", getComputerParts());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long computerId = (Long)attributes.get("computerId");

		if (computerId != null) {
			setComputerId(computerId);
		}

		String computerName = (String)attributes.get("computerName");

		if (computerName != null) {
			setComputerName(computerName);
		}

		String computerParts = (String)attributes.get("computerParts");

		if (computerParts != null) {
			setComputerParts(computerParts);
		}
	}

	/**
	 * Returns the computer ID of this computer.
	 *
	 * @return the computer ID of this computer
	 */
	@Override
	public long getComputerId() {
		return model.getComputerId();
	}

	/**
	 * Returns the computer name of this computer.
	 *
	 * @return the computer name of this computer
	 */
	@Override
	public String getComputerName() {
		return model.getComputerName();
	}

	/**
	 * Returns the computer parts of this computer.
	 *
	 * @return the computer parts of this computer
	 */
	@Override
	public String getComputerParts() {
		return model.getComputerParts();
	}

	/**
	 * Returns the primary key of this computer.
	 *
	 * @return the primary key of this computer
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this computer.
	 *
	 * @return the uuid of this computer
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the computer ID of this computer.
	 *
	 * @param computerId the computer ID of this computer
	 */
	@Override
	public void setComputerId(long computerId) {
		model.setComputerId(computerId);
	}

	/**
	 * Sets the computer name of this computer.
	 *
	 * @param computerName the computer name of this computer
	 */
	@Override
	public void setComputerName(String computerName) {
		model.setComputerName(computerName);
	}

	/**
	 * Sets the computer parts of this computer.
	 *
	 * @param computerParts the computer parts of this computer
	 */
	@Override
	public void setComputerParts(String computerParts) {
		model.setComputerParts(computerParts);
	}

	/**
	 * Sets the primary key of this computer.
	 *
	 * @param primaryKey the primary key of this computer
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this computer.
	 *
	 * @param uuid the uuid of this computer
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected ComputerWrapper wrap(Computer computer) {
		return new ComputerWrapper(computer);
	}

}