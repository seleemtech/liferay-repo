/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.computerservice.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.computerservice.service.http.ComputerServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ComputerSoap implements Serializable {

	public static ComputerSoap toSoapModel(Computer model) {
		ComputerSoap soapModel = new ComputerSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setComputerId(model.getComputerId());
		soapModel.setComputerName(model.getComputerName());
		soapModel.setComputerParts(model.getComputerParts());

		return soapModel;
	}

	public static ComputerSoap[] toSoapModels(Computer[] models) {
		ComputerSoap[] soapModels = new ComputerSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ComputerSoap[][] toSoapModels(Computer[][] models) {
		ComputerSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ComputerSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ComputerSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ComputerSoap[] toSoapModels(List<Computer> models) {
		List<ComputerSoap> soapModels = new ArrayList<ComputerSoap>(
			models.size());

		for (Computer model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ComputerSoap[soapModels.size()]);
	}

	public ComputerSoap() {
	}

	public long getPrimaryKey() {
		return _computerId;
	}

	public void setPrimaryKey(long pk) {
		setComputerId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getComputerId() {
		return _computerId;
	}

	public void setComputerId(long computerId) {
		_computerId = computerId;
	}

	public String getComputerName() {
		return _computerName;
	}

	public void setComputerName(String computerName) {
		_computerName = computerName;
	}

	public String getComputerParts() {
		return _computerParts;
	}

	public void setComputerParts(String computerParts) {
		_computerParts = computerParts;
	}

	private String _uuid;
	private long _computerId;
	private String _computerName;
	private String _computerParts;

}