/**
 * SPDX-FileCopyrightText: (c) 2025 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.global.custom.search.service.impl;

import com.global.custom.search.model.Student;
import com.global.custom.search.service.base.StudentLocalServiceBaseImpl;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.search.Indexable;
import com.liferay.portal.kernel.search.IndexableType;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.ContentTypes;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Brian Wing Shun Chan
 */
@Component(property = "model.class.name=com.global.custom.search.model.Student", service = AopService.class)
public class StudentLocalServiceImpl extends StudentLocalServiceBaseImpl {

	@Indexable(type = IndexableType.REINDEX)
	public Student addS5E6Entry(long userId, long groupId, String description, String item, String classType,
			ServiceContext serviceContext) throws PortalException {

		Student student = studentPersistence.create(counterLocalService.increment());

		student.setUuid(serviceContext.getUuid());
		student.setGroupId(groupId);

		User user = _userLocalService.getUser(userId);

		student.setCompanyId(user.getCompanyId());
		student.setUserId(user.getUserId());
		student.setUserName(user.getFullName());

		student.setDescription(description);
		student.setName(item);
		student.setClassType(classType);

		student = studentPersistence.update(student);

		assetEntryLocalService.updateEntry(student.getUserId(), student.getGroupId(), student.getCreateDate(),
				student.getModifiedDate(), Student.class.getName(), student.getStudentId(), student.getUuid(),
				0, null, null, true, true, null, null, null, null, ContentTypes.TEXT, student.getName(),
				student.getDescription(), student.getDescription(), null, null, 0, 0, 1.0);

		return student;
	}

	@Reference
	private UserLocalService _userLocalService;
}