package com.global.custom.search.search;

import com.global.custom.search.model.Student;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.search.spi.model.index.contributor.ModelDocumentContributor;

import org.osgi.service.component.annotations.Component;

@Component(
	property = "indexer.class.name=com.global.custom.search.model.Student",
	service = ModelDocumentContributor.class
)
public class StudentModelDocumentContributor
	implements ModelDocumentContributor<Student> {

	@Override
	public void contribute(Document document, Student student) {
		document.addText(Field.TITLE, student.getName());
		document.addText("classType", student.getClassType());
	}

}