package global.custom.search.web.internal.asset;

import com.global.custom.search.model.Student;
import com.global.custom.search.service.StudentLocalService;
import com.liferay.asset.kernel.model.AssetRenderer;
import com.liferay.asset.kernel.model.AssetRendererFactory;
import com.liferay.asset.kernel.model.BaseAssetRendererFactory;
import com.liferay.portal.kernel.exception.PortalException;

import java.util.Locale;

import javax.servlet.ServletContext;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(service = AssetRendererFactory.class)
public class StudentAssetRendererFactory
	extends BaseAssetRendererFactory<Student> {

	public static final String TYPE = "student";

	public StudentAssetRendererFactory() {
		setClassName(Student.class.getName());
		setLinkable(true);
		setPortletId("global_custom_search_web_GlobalCustomSearchWebPortlet");
		setSearchable(true);
	}

	@Override
	public AssetRenderer<Student> getAssetRenderer(long classPK, int type)
		throws PortalException {

		StudentAssetRenderer studentAssetRenderer =
			new StudentAssetRenderer(
					_studnetLocalService.getStudent(classPK));

		studentAssetRenderer.setAssetRendererType(type);
		studentAssetRenderer.setServletContext(_servletContext);

		return studentAssetRenderer;
	}

	@Override
	public String getType() {
		return TYPE;
	}

	@Override
	public String getTypeName(Locale locale) {
		return "student";
	}

	@Reference
	private StudentLocalService _studnetLocalService;

	@Reference(target = "(osgi.web.symbolicname=global.custom.search.web)")
	private ServletContext _servletContext;

}