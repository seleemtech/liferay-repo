package global.custom.search.web.constants;

/**
 * @author Mahammad.Saleem
 */
public class GlobalCustomSearchWebPortletKeys {

	public static final String GLOBALCUSTOMSEARCHWEB =
		"global_custom_search_web_GlobalCustomSearchWebPortlet";

}