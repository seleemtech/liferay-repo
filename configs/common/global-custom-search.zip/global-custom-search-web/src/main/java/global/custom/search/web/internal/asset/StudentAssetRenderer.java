package global.custom.search.web.internal.asset;

import com.global.custom.search.model.Student;
import com.liferay.asset.kernel.model.BaseJSPAssetRenderer;

import java.util.Locale;

import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.servlet.http.HttpServletRequest;

public class StudentAssetRenderer extends BaseJSPAssetRenderer<Student> {

	public StudentAssetRenderer(Student student) {
		_student = student;
	}

	@Override
	public Student getAssetObject() {
		return _student;
	}

	@Override
	public String getClassName() {
		return Student.class.getName();
	}

	@Override
	public long getClassPK() {
		return _student.getStudentId();
	}

	@Override
	public long getGroupId() {
		return _student.getGroupId();
	}

	@Override
	public String getJspPath(
		HttpServletRequest httpServletRequest, String template) {

		return null;
	}

	@Override
	public String getSummary(
		PortletRequest portletRequest, PortletResponse portletResponse) {

		return _student.getDescription();
	}

	@Override
	public String getTitle(Locale locale) {
		return _student.getName();
	}

	@Override
	public long getUserId() {
		return _student.getUserId();
	}

	@Override
	public String getUserName() {
		return _student.getUserName();
	}

	@Override
	public String getUuid() {
		return _student.getUuid();
	}

	private Student _student;

}