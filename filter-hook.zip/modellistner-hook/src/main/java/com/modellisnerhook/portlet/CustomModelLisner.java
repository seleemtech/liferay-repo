package com.modellisnerhook.portlet;

import com.liferay.portal.kernel.exception.ModelListenerException;
import com.liferay.portal.kernel.model.BaseModelListener;
import com.liferay.portal.kernel.model.ModelListener;
import com.liferay.portal.kernel.model.User;

import org.osgi.service.component.annotations.Component;

@Component(
		 immediate = true,
		 service = ModelListener.class
		)
public class CustomModelLisner extends BaseModelListener<User> {
	@Override
	public void onAfterUpdate(User model) throws ModelListenerException {
		// TODO Auto-generated method stub
		System.out.println("user is updating");
		super.onAfterUpdate(model);
	}

}
