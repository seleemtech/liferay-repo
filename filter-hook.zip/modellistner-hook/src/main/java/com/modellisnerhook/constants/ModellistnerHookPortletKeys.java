package com.modellisnerhook.constants;

/**
 * @author DELL
 */
public class ModellistnerHookPortletKeys {

	public static final String MODELLISTNERHOOK =
		"com_modellisnerhook_ModellistnerHookPortlet";

}