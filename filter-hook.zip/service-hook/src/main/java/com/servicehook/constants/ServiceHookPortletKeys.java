package com.servicehook.constants;

/**
 * @author DELL
 */
public class ServiceHookPortletKeys {

	public static final String SERVICEHOOK =
		"com_servicehook_ServiceHookPortlet";

}