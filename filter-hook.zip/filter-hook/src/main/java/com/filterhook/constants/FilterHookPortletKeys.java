package com.filterhook.constants;

/**
 * @author DELL
 */
public class FilterHookPortletKeys {

	public static final String FILTERHOOK =
		"com_filterhook_FilterHookPortlet";

}