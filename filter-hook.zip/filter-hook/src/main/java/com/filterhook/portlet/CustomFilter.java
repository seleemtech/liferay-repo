package com.filterhook.portlet;

import com.liferay.mail.kernel.model.Filter;
import com.liferay.portal.kernel.search.filter.BaseFilter;
import com.liferay.portal.kernel.search.filter.FilterVisitor;

import org.osgi.service.component.annotations.Component;

@Component(
		 immediate = true, 
		 property = {
		 "servlet-context-name=", 
		 "servlet-filter-name=Custom Filter",
		 "url-pattern=/*" 
		 }, 
		 service = Filter.class
		 )
public class CustomFilter extends BaseFilter {

	@Override
	public <T> T accept(FilterVisitor<T> filterVisitor) {
		// TODO Auto-generated method stub

		return null;
	}

	@Override
	public int getSortOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

}
