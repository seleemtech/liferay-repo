/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.country.service.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EmployeeRecords}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EmployeeRecords
 * @generated
 */
public class EmployeeRecordsWrapper
	extends BaseModelWrapper<EmployeeRecords>
	implements EmployeeRecords, ModelWrapper<EmployeeRecords> {

	public EmployeeRecordsWrapper(EmployeeRecords employeeRecords) {
		super(employeeRecords);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("employeeId", getEmployeeId());
		attributes.put("employeeNmae", getEmployeeNmae());
		attributes.put("state", getState());
		attributes.put("country", getCountry());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long employeeId = (Long)attributes.get("employeeId");

		if (employeeId != null) {
			setEmployeeId(employeeId);
		}

		String employeeNmae = (String)attributes.get("employeeNmae");

		if (employeeNmae != null) {
			setEmployeeNmae(employeeNmae);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String country = (String)attributes.get("country");

		if (country != null) {
			setCountry(country);
		}
	}

	/**
	 * Returns the country of this employee records.
	 *
	 * @return the country of this employee records
	 */
	@Override
	public String getCountry() {
		return model.getCountry();
	}

	/**
	 * Returns the employee ID of this employee records.
	 *
	 * @return the employee ID of this employee records
	 */
	@Override
	public long getEmployeeId() {
		return model.getEmployeeId();
	}

	/**
	 * Returns the employee nmae of this employee records.
	 *
	 * @return the employee nmae of this employee records
	 */
	@Override
	public String getEmployeeNmae() {
		return model.getEmployeeNmae();
	}

	/**
	 * Returns the primary key of this employee records.
	 *
	 * @return the primary key of this employee records
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the state of this employee records.
	 *
	 * @return the state of this employee records
	 */
	@Override
	public String getState() {
		return model.getState();
	}

	/**
	 * Returns the uuid of this employee records.
	 *
	 * @return the uuid of this employee records
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the country of this employee records.
	 *
	 * @param country the country of this employee records
	 */
	@Override
	public void setCountry(String country) {
		model.setCountry(country);
	}

	/**
	 * Sets the employee ID of this employee records.
	 *
	 * @param employeeId the employee ID of this employee records
	 */
	@Override
	public void setEmployeeId(long employeeId) {
		model.setEmployeeId(employeeId);
	}

	/**
	 * Sets the employee nmae of this employee records.
	 *
	 * @param employeeNmae the employee nmae of this employee records
	 */
	@Override
	public void setEmployeeNmae(String employeeNmae) {
		model.setEmployeeNmae(employeeNmae);
	}

	/**
	 * Sets the primary key of this employee records.
	 *
	 * @param primaryKey the primary key of this employee records
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the state of this employee records.
	 *
	 * @param state the state of this employee records
	 */
	@Override
	public void setState(String state) {
		model.setState(state);
	}

	/**
	 * Sets the uuid of this employee records.
	 *
	 * @param uuid the uuid of this employee records
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected EmployeeRecordsWrapper wrap(EmployeeRecords employeeRecords) {
		return new EmployeeRecordsWrapper(employeeRecords);
	}

}