/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.country.service.service.persistence;

import com.country.service.exception.NoSuchStateTableException;
import com.country.service.model.StateTable;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the state table service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see StateTableUtil
 * @generated
 */
@ProviderType
public interface StateTablePersistence extends BasePersistence<StateTable> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link StateTableUtil} to access the state table persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the state tables where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching state tables
	 */
	public java.util.List<StateTable> findByUuid(String uuid);

	/**
	 * Returns a range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of matching state tables
	 */
	public java.util.List<StateTable> findByUuid(
		String uuid, int start, int end);

	/**
	 * Returns an ordered range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching state tables
	 */
	public java.util.List<StateTable> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns an ordered range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching state tables
	 */
	public java.util.List<StateTable> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public StateTable findByUuid_First(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<StateTable>
				orderByComparator)
		throws NoSuchStateTableException;

	/**
	 * Returns the first state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public StateTable fetchByUuid_First(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns the last state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public StateTable findByUuid_Last(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<StateTable>
				orderByComparator)
		throws NoSuchStateTableException;

	/**
	 * Returns the last state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public StateTable fetchByUuid_Last(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns the state tables before and after the current state table in the ordered set where uuid = &#63;.
	 *
	 * @param stateId the primary key of the current state table
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public StateTable[] findByUuid_PrevAndNext(
			long stateId, String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<StateTable>
				orderByComparator)
		throws NoSuchStateTableException;

	/**
	 * Removes all the state tables where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public void removeByUuid(String uuid);

	/**
	 * Returns the number of state tables where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching state tables
	 */
	public int countByUuid(String uuid);

	/**
	 * Returns all the state tables where country = &#63;.
	 *
	 * @param country the country
	 * @return the matching state tables
	 */
	public java.util.List<StateTable> findByCountry(String country);

	/**
	 * Returns a range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of matching state tables
	 */
	public java.util.List<StateTable> findByCountry(
		String country, int start, int end);

	/**
	 * Returns an ordered range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching state tables
	 */
	public java.util.List<StateTable> findByCountry(
		String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns an ordered range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching state tables
	 */
	public java.util.List<StateTable> findByCountry(
		String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public StateTable findByCountry_First(
			String country,
			com.liferay.portal.kernel.util.OrderByComparator<StateTable>
				orderByComparator)
		throws NoSuchStateTableException;

	/**
	 * Returns the first state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public StateTable fetchByCountry_First(
		String country,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns the last state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public StateTable findByCountry_Last(
			String country,
			com.liferay.portal.kernel.util.OrderByComparator<StateTable>
				orderByComparator)
		throws NoSuchStateTableException;

	/**
	 * Returns the last state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public StateTable fetchByCountry_Last(
		String country,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns the state tables before and after the current state table in the ordered set where country = &#63;.
	 *
	 * @param stateId the primary key of the current state table
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public StateTable[] findByCountry_PrevAndNext(
			long stateId, String country,
			com.liferay.portal.kernel.util.OrderByComparator<StateTable>
				orderByComparator)
		throws NoSuchStateTableException;

	/**
	 * Removes all the state tables where country = &#63; from the database.
	 *
	 * @param country the country
	 */
	public void removeByCountry(String country);

	/**
	 * Returns the number of state tables where country = &#63;.
	 *
	 * @param country the country
	 * @return the number of matching state tables
	 */
	public int countByCountry(String country);

	/**
	 * Caches the state table in the entity cache if it is enabled.
	 *
	 * @param stateTable the state table
	 */
	public void cacheResult(StateTable stateTable);

	/**
	 * Caches the state tables in the entity cache if it is enabled.
	 *
	 * @param stateTables the state tables
	 */
	public void cacheResult(java.util.List<StateTable> stateTables);

	/**
	 * Creates a new state table with the primary key. Does not add the state table to the database.
	 *
	 * @param stateId the primary key for the new state table
	 * @return the new state table
	 */
	public StateTable create(long stateId);

	/**
	 * Removes the state table with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table that was removed
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public StateTable remove(long stateId) throws NoSuchStateTableException;

	public StateTable updateImpl(StateTable stateTable);

	/**
	 * Returns the state table with the primary key or throws a <code>NoSuchStateTableException</code> if it could not be found.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public StateTable findByPrimaryKey(long stateId)
		throws NoSuchStateTableException;

	/**
	 * Returns the state table with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table, or <code>null</code> if a state table with the primary key could not be found
	 */
	public StateTable fetchByPrimaryKey(long stateId);

	/**
	 * Returns all the state tables.
	 *
	 * @return the state tables
	 */
	public java.util.List<StateTable> findAll();

	/**
	 * Returns a range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of state tables
	 */
	public java.util.List<StateTable> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of state tables
	 */
	public java.util.List<StateTable> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator);

	/**
	 * Returns an ordered range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of state tables
	 */
	public java.util.List<StateTable> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<StateTable>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the state tables from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of state tables.
	 *
	 * @return the number of state tables
	 */
	public int countAll();

}