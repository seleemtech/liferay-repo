/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.country.service.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.country.service.service.http.StateTableServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class StateTableSoap implements Serializable {

	public static StateTableSoap toSoapModel(StateTable model) {
		StateTableSoap soapModel = new StateTableSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setStateId(model.getStateId());
		soapModel.setCountry(model.getCountry());
		soapModel.setState(model.getState());

		return soapModel;
	}

	public static StateTableSoap[] toSoapModels(StateTable[] models) {
		StateTableSoap[] soapModels = new StateTableSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static StateTableSoap[][] toSoapModels(StateTable[][] models) {
		StateTableSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new StateTableSoap[models.length][models[0].length];
		}
		else {
			soapModels = new StateTableSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static StateTableSoap[] toSoapModels(List<StateTable> models) {
		List<StateTableSoap> soapModels = new ArrayList<StateTableSoap>(
			models.size());

		for (StateTable model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new StateTableSoap[soapModels.size()]);
	}

	public StateTableSoap() {
	}

	public long getPrimaryKey() {
		return _stateId;
	}

	public void setPrimaryKey(long pk) {
		setStateId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getStateId() {
		return _stateId;
	}

	public void setStateId(long stateId) {
		_stateId = stateId;
	}

	public String getCountry() {
		return _country;
	}

	public void setCountry(String country) {
		_country = country;
	}

	public String getState() {
		return _state;
	}

	public void setState(String state) {
		_state = state;
	}

	private String _uuid;
	private long _stateId;
	private String _country;
	private String _state;

}