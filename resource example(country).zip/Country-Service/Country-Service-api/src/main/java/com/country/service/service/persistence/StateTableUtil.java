/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.country.service.service.persistence;

import com.country.service.model.StateTable;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the state table service. This utility wraps <code>com.country.service.service.persistence.impl.StateTablePersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see StateTablePersistence
 * @generated
 */
public class StateTableUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(StateTable stateTable) {
		getPersistence().clearCache(stateTable);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, StateTable> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<StateTable> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<StateTable> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<StateTable> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static StateTable update(StateTable stateTable) {
		return getPersistence().update(stateTable);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static StateTable update(
		StateTable stateTable, ServiceContext serviceContext) {

		return getPersistence().update(stateTable, serviceContext);
	}

	/**
	 * Returns all the state tables where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching state tables
	 */
	public static List<StateTable> findByUuid(String uuid) {
		return getPersistence().findByUuid(uuid);
	}

	/**
	 * Returns a range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of matching state tables
	 */
	public static List<StateTable> findByUuid(String uuid, int start, int end) {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	 * Returns an ordered range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching state tables
	 */
	public static List<StateTable> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching state tables
	 */
	public static List<StateTable> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<StateTable> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByUuid(
			uuid, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public static StateTable findByUuid_First(
			String uuid, OrderByComparator<StateTable> orderByComparator)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the first state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public static StateTable fetchByUuid_First(
		String uuid, OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the last state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public static StateTable findByUuid_Last(
			String uuid, OrderByComparator<StateTable> orderByComparator)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the last state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public static StateTable fetchByUuid_Last(
		String uuid, OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the state tables before and after the current state table in the ordered set where uuid = &#63;.
	 *
	 * @param stateId the primary key of the current state table
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public static StateTable[] findByUuid_PrevAndNext(
			long stateId, String uuid,
			OrderByComparator<StateTable> orderByComparator)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByUuid_PrevAndNext(
			stateId, uuid, orderByComparator);
	}

	/**
	 * Removes all the state tables where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public static void removeByUuid(String uuid) {
		getPersistence().removeByUuid(uuid);
	}

	/**
	 * Returns the number of state tables where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching state tables
	 */
	public static int countByUuid(String uuid) {
		return getPersistence().countByUuid(uuid);
	}

	/**
	 * Returns all the state tables where country = &#63;.
	 *
	 * @param country the country
	 * @return the matching state tables
	 */
	public static List<StateTable> findByCountry(String country) {
		return getPersistence().findByCountry(country);
	}

	/**
	 * Returns a range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of matching state tables
	 */
	public static List<StateTable> findByCountry(
		String country, int start, int end) {

		return getPersistence().findByCountry(country, start, end);
	}

	/**
	 * Returns an ordered range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching state tables
	 */
	public static List<StateTable> findByCountry(
		String country, int start, int end,
		OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().findByCountry(
			country, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching state tables
	 */
	public static List<StateTable> findByCountry(
		String country, int start, int end,
		OrderByComparator<StateTable> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByCountry(
			country, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public static StateTable findByCountry_First(
			String country, OrderByComparator<StateTable> orderByComparator)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByCountry_First(country, orderByComparator);
	}

	/**
	 * Returns the first state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public static StateTable fetchByCountry_First(
		String country, OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().fetchByCountry_First(
			country, orderByComparator);
	}

	/**
	 * Returns the last state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	public static StateTable findByCountry_Last(
			String country, OrderByComparator<StateTable> orderByComparator)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByCountry_Last(country, orderByComparator);
	}

	/**
	 * Returns the last state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table, or <code>null</code> if a matching state table could not be found
	 */
	public static StateTable fetchByCountry_Last(
		String country, OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().fetchByCountry_Last(country, orderByComparator);
	}

	/**
	 * Returns the state tables before and after the current state table in the ordered set where country = &#63;.
	 *
	 * @param stateId the primary key of the current state table
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public static StateTable[] findByCountry_PrevAndNext(
			long stateId, String country,
			OrderByComparator<StateTable> orderByComparator)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByCountry_PrevAndNext(
			stateId, country, orderByComparator);
	}

	/**
	 * Removes all the state tables where country = &#63; from the database.
	 *
	 * @param country the country
	 */
	public static void removeByCountry(String country) {
		getPersistence().removeByCountry(country);
	}

	/**
	 * Returns the number of state tables where country = &#63;.
	 *
	 * @param country the country
	 * @return the number of matching state tables
	 */
	public static int countByCountry(String country) {
		return getPersistence().countByCountry(country);
	}

	/**
	 * Caches the state table in the entity cache if it is enabled.
	 *
	 * @param stateTable the state table
	 */
	public static void cacheResult(StateTable stateTable) {
		getPersistence().cacheResult(stateTable);
	}

	/**
	 * Caches the state tables in the entity cache if it is enabled.
	 *
	 * @param stateTables the state tables
	 */
	public static void cacheResult(List<StateTable> stateTables) {
		getPersistence().cacheResult(stateTables);
	}

	/**
	 * Creates a new state table with the primary key. Does not add the state table to the database.
	 *
	 * @param stateId the primary key for the new state table
	 * @return the new state table
	 */
	public static StateTable create(long stateId) {
		return getPersistence().create(stateId);
	}

	/**
	 * Removes the state table with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table that was removed
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public static StateTable remove(long stateId)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().remove(stateId);
	}

	public static StateTable updateImpl(StateTable stateTable) {
		return getPersistence().updateImpl(stateTable);
	}

	/**
	 * Returns the state table with the primary key or throws a <code>NoSuchStateTableException</code> if it could not be found.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	public static StateTable findByPrimaryKey(long stateId)
		throws com.country.service.exception.NoSuchStateTableException {

		return getPersistence().findByPrimaryKey(stateId);
	}

	/**
	 * Returns the state table with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table, or <code>null</code> if a state table with the primary key could not be found
	 */
	public static StateTable fetchByPrimaryKey(long stateId) {
		return getPersistence().fetchByPrimaryKey(stateId);
	}

	/**
	 * Returns all the state tables.
	 *
	 * @return the state tables
	 */
	public static List<StateTable> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of state tables
	 */
	public static List<StateTable> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of state tables
	 */
	public static List<StateTable> findAll(
		int start, int end, OrderByComparator<StateTable> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of state tables
	 */
	public static List<StateTable> findAll(
		int start, int end, OrderByComparator<StateTable> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the state tables from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of state tables.
	 *
	 * @return the number of state tables
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static StateTablePersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<StateTablePersistence, StateTablePersistence>
		_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(StateTablePersistence.class);

		ServiceTracker<StateTablePersistence, StateTablePersistence>
			serviceTracker =
				new ServiceTracker
					<StateTablePersistence, StateTablePersistence>(
						bundle.getBundleContext(), StateTablePersistence.class,
						null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}