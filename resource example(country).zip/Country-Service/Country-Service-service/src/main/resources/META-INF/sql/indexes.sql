create index IX_C278CD5D on FOO_CountryTable (uuid_[$COLUMN_LENGTH:75$]);

create index IX_66E4E393 on FOO_EmployeeRecords (uuid_[$COLUMN_LENGTH:75$]);

create index IX_E02D936A on FOO_StateTable (country[$COLUMN_LENGTH:75$]);
create index IX_FDEAFCD8 on FOO_StateTable (uuid_[$COLUMN_LENGTH:75$]);