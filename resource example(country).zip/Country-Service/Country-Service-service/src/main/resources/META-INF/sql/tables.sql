create table FOO_CountryTable (
	uuid_ VARCHAR(75) null,
	countryId LONG not null primary key,
	country VARCHAR(75) null
);

create table FOO_EmployeeRecords (
	uuid_ VARCHAR(75) null,
	employeeId LONG not null primary key,
	employeeNmae VARCHAR(75) null,
	state_ VARCHAR(75) null,
	country VARCHAR(75) null
);

create table FOO_StateTable (
	uuid_ VARCHAR(75) null,
	stateId LONG not null primary key,
	country VARCHAR(75) null,
	state_ VARCHAR(75) null
);