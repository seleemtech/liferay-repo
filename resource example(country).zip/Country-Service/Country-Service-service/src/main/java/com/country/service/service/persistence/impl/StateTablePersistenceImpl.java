/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.country.service.service.persistence.impl;

import com.country.service.exception.NoSuchStateTableException;
import com.country.service.model.StateTable;
import com.country.service.model.impl.StateTableImpl;
import com.country.service.model.impl.StateTableModelImpl;
import com.country.service.service.persistence.StateTablePersistence;
import com.country.service.service.persistence.impl.constants.FOOPersistenceConstants;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the state table service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = StateTablePersistence.class)
public class StateTablePersistenceImpl
	extends BasePersistenceImpl<StateTable> implements StateTablePersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>StateTableUtil</code> to access the state table persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		StateTableImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByUuid;
	private FinderPath _finderPathWithoutPaginationFindByUuid;
	private FinderPath _finderPathCountByUuid;

	/**
	 * Returns all the state tables where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching state tables
	 */
	@Override
	public List<StateTable> findByUuid(String uuid) {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of matching state tables
	 */
	@Override
	public List<StateTable> findByUuid(String uuid, int start, int end) {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching state tables
	 */
	@Override
	public List<StateTable> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<StateTable> orderByComparator) {

		return findByUuid(uuid, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the state tables where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching state tables
	 */
	@Override
	public List<StateTable> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<StateTable> orderByComparator,
		boolean useFinderCache) {

		uuid = Objects.toString(uuid, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByUuid;
				finderArgs = new Object[] {uuid};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByUuid;
			finderArgs = new Object[] {uuid, start, end, orderByComparator};
		}

		List<StateTable> list = null;

		if (useFinderCache) {
			list = (List<StateTable>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (StateTable stateTable : list) {
					if (!uuid.equals(stateTable.getUuid())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_STATETABLE_WHERE);

			boolean bindUuid = false;

			if (uuid.isEmpty()) {
				sb.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				sb.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(StateTableModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindUuid) {
					queryPos.add(uuid);
				}

				list = (List<StateTable>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				if (useFinderCache) {
					finderCache.removeResult(finderPath, finderArgs);
				}

				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	@Override
	public StateTable findByUuid_First(
			String uuid, OrderByComparator<StateTable> orderByComparator)
		throws NoSuchStateTableException {

		StateTable stateTable = fetchByUuid_First(uuid, orderByComparator);

		if (stateTable != null) {
			return stateTable;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("uuid=");
		sb.append(uuid);

		sb.append("}");

		throw new NoSuchStateTableException(sb.toString());
	}

	/**
	 * Returns the first state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table, or <code>null</code> if a matching state table could not be found
	 */
	@Override
	public StateTable fetchByUuid_First(
		String uuid, OrderByComparator<StateTable> orderByComparator) {

		List<StateTable> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	@Override
	public StateTable findByUuid_Last(
			String uuid, OrderByComparator<StateTable> orderByComparator)
		throws NoSuchStateTableException {

		StateTable stateTable = fetchByUuid_Last(uuid, orderByComparator);

		if (stateTable != null) {
			return stateTable;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("uuid=");
		sb.append(uuid);

		sb.append("}");

		throw new NoSuchStateTableException(sb.toString());
	}

	/**
	 * Returns the last state table in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table, or <code>null</code> if a matching state table could not be found
	 */
	@Override
	public StateTable fetchByUuid_Last(
		String uuid, OrderByComparator<StateTable> orderByComparator) {

		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<StateTable> list = findByUuid(
			uuid, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the state tables before and after the current state table in the ordered set where uuid = &#63;.
	 *
	 * @param stateId the primary key of the current state table
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	@Override
	public StateTable[] findByUuid_PrevAndNext(
			long stateId, String uuid,
			OrderByComparator<StateTable> orderByComparator)
		throws NoSuchStateTableException {

		uuid = Objects.toString(uuid, "");

		StateTable stateTable = findByPrimaryKey(stateId);

		Session session = null;

		try {
			session = openSession();

			StateTable[] array = new StateTableImpl[3];

			array[0] = getByUuid_PrevAndNext(
				session, stateTable, uuid, orderByComparator, true);

			array[1] = stateTable;

			array[2] = getByUuid_PrevAndNext(
				session, stateTable, uuid, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected StateTable getByUuid_PrevAndNext(
		Session session, StateTable stateTable, String uuid,
		OrderByComparator<StateTable> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_STATETABLE_WHERE);

		boolean bindUuid = false;

		if (uuid.isEmpty()) {
			sb.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			sb.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(StateTableModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindUuid) {
			queryPos.add(uuid);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(stateTable)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<StateTable> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the state tables where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	@Override
	public void removeByUuid(String uuid) {
		for (StateTable stateTable :
				findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(stateTable);
		}
	}

	/**
	 * Returns the number of state tables where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching state tables
	 */
	@Override
	public int countByUuid(String uuid) {
		uuid = Objects.toString(uuid, "");

		FinderPath finderPath = _finderPathCountByUuid;

		Object[] finderArgs = new Object[] {uuid};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_STATETABLE_WHERE);

			boolean bindUuid = false;

			if (uuid.isEmpty()) {
				sb.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				sb.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindUuid) {
					queryPos.add(uuid);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_2 =
		"stateTable.uuid = ?";

	private static final String _FINDER_COLUMN_UUID_UUID_3 =
		"(stateTable.uuid IS NULL OR stateTable.uuid = '')";

	private FinderPath _finderPathWithPaginationFindByCountry;
	private FinderPath _finderPathWithoutPaginationFindByCountry;
	private FinderPath _finderPathCountByCountry;

	/**
	 * Returns all the state tables where country = &#63;.
	 *
	 * @param country the country
	 * @return the matching state tables
	 */
	@Override
	public List<StateTable> findByCountry(String country) {
		return findByCountry(
			country, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of matching state tables
	 */
	@Override
	public List<StateTable> findByCountry(String country, int start, int end) {
		return findByCountry(country, start, end, null);
	}

	/**
	 * Returns an ordered range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching state tables
	 */
	@Override
	public List<StateTable> findByCountry(
		String country, int start, int end,
		OrderByComparator<StateTable> orderByComparator) {

		return findByCountry(country, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the state tables where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching state tables
	 */
	@Override
	public List<StateTable> findByCountry(
		String country, int start, int end,
		OrderByComparator<StateTable> orderByComparator,
		boolean useFinderCache) {

		country = Objects.toString(country, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByCountry;
				finderArgs = new Object[] {country};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByCountry;
			finderArgs = new Object[] {country, start, end, orderByComparator};
		}

		List<StateTable> list = null;

		if (useFinderCache) {
			list = (List<StateTable>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (StateTable stateTable : list) {
					if (!country.equals(stateTable.getCountry())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_STATETABLE_WHERE);

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(StateTableModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCountry) {
					queryPos.add(country);
				}

				list = (List<StateTable>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				if (useFinderCache) {
					finderCache.removeResult(finderPath, finderArgs);
				}

				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	@Override
	public StateTable findByCountry_First(
			String country, OrderByComparator<StateTable> orderByComparator)
		throws NoSuchStateTableException {

		StateTable stateTable = fetchByCountry_First(
			country, orderByComparator);

		if (stateTable != null) {
			return stateTable;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchStateTableException(sb.toString());
	}

	/**
	 * Returns the first state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching state table, or <code>null</code> if a matching state table could not be found
	 */
	@Override
	public StateTable fetchByCountry_First(
		String country, OrderByComparator<StateTable> orderByComparator) {

		List<StateTable> list = findByCountry(country, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table
	 * @throws NoSuchStateTableException if a matching state table could not be found
	 */
	@Override
	public StateTable findByCountry_Last(
			String country, OrderByComparator<StateTable> orderByComparator)
		throws NoSuchStateTableException {

		StateTable stateTable = fetchByCountry_Last(country, orderByComparator);

		if (stateTable != null) {
			return stateTable;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchStateTableException(sb.toString());
	}

	/**
	 * Returns the last state table in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching state table, or <code>null</code> if a matching state table could not be found
	 */
	@Override
	public StateTable fetchByCountry_Last(
		String country, OrderByComparator<StateTable> orderByComparator) {

		int count = countByCountry(country);

		if (count == 0) {
			return null;
		}

		List<StateTable> list = findByCountry(
			country, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the state tables before and after the current state table in the ordered set where country = &#63;.
	 *
	 * @param stateId the primary key of the current state table
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	@Override
	public StateTable[] findByCountry_PrevAndNext(
			long stateId, String country,
			OrderByComparator<StateTable> orderByComparator)
		throws NoSuchStateTableException {

		country = Objects.toString(country, "");

		StateTable stateTable = findByPrimaryKey(stateId);

		Session session = null;

		try {
			session = openSession();

			StateTable[] array = new StateTableImpl[3];

			array[0] = getByCountry_PrevAndNext(
				session, stateTable, country, orderByComparator, true);

			array[1] = stateTable;

			array[2] = getByCountry_PrevAndNext(
				session, stateTable, country, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected StateTable getByCountry_PrevAndNext(
		Session session, StateTable stateTable, String country,
		OrderByComparator<StateTable> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_STATETABLE_WHERE);

		boolean bindCountry = false;

		if (country.isEmpty()) {
			sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_3);
		}
		else {
			bindCountry = true;

			sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(StateTableModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindCountry) {
			queryPos.add(country);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(stateTable)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<StateTable> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the state tables where country = &#63; from the database.
	 *
	 * @param country the country
	 */
	@Override
	public void removeByCountry(String country) {
		for (StateTable stateTable :
				findByCountry(
					country, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(stateTable);
		}
	}

	/**
	 * Returns the number of state tables where country = &#63;.
	 *
	 * @param country the country
	 * @return the number of matching state tables
	 */
	@Override
	public int countByCountry(String country) {
		country = Objects.toString(country, "");

		FinderPath finderPath = _finderPathCountByCountry;

		Object[] finderArgs = new Object[] {country};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_STATETABLE_WHERE);

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCountry) {
					queryPos.add(country);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COUNTRY_COUNTRY_2 =
		"stateTable.country = ?";

	private static final String _FINDER_COLUMN_COUNTRY_COUNTRY_3 =
		"(stateTable.country IS NULL OR stateTable.country = '')";

	public StateTablePersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("uuid", "uuid_");
		dbColumnNames.put("state", "state_");

		setDBColumnNames(dbColumnNames);

		setModelClass(StateTable.class);

		setModelImplClass(StateTableImpl.class);
		setModelPKClass(long.class);
	}

	/**
	 * Caches the state table in the entity cache if it is enabled.
	 *
	 * @param stateTable the state table
	 */
	@Override
	public void cacheResult(StateTable stateTable) {
		entityCache.putResult(
			entityCacheEnabled, StateTableImpl.class,
			stateTable.getPrimaryKey(), stateTable);

		stateTable.resetOriginalValues();
	}

	/**
	 * Caches the state tables in the entity cache if it is enabled.
	 *
	 * @param stateTables the state tables
	 */
	@Override
	public void cacheResult(List<StateTable> stateTables) {
		for (StateTable stateTable : stateTables) {
			if (entityCache.getResult(
					entityCacheEnabled, StateTableImpl.class,
					stateTable.getPrimaryKey()) == null) {

				cacheResult(stateTable);
			}
			else {
				stateTable.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all state tables.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(StateTableImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the state table.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(StateTable stateTable) {
		entityCache.removeResult(
			entityCacheEnabled, StateTableImpl.class,
			stateTable.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<StateTable> stateTables) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (StateTable stateTable : stateTables) {
			entityCache.removeResult(
				entityCacheEnabled, StateTableImpl.class,
				stateTable.getPrimaryKey());
		}
	}

	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(
				entityCacheEnabled, StateTableImpl.class, primaryKey);
		}
	}

	/**
	 * Creates a new state table with the primary key. Does not add the state table to the database.
	 *
	 * @param stateId the primary key for the new state table
	 * @return the new state table
	 */
	@Override
	public StateTable create(long stateId) {
		StateTable stateTable = new StateTableImpl();

		stateTable.setNew(true);
		stateTable.setPrimaryKey(stateId);

		String uuid = PortalUUIDUtil.generate();

		stateTable.setUuid(uuid);

		return stateTable;
	}

	/**
	 * Removes the state table with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table that was removed
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	@Override
	public StateTable remove(long stateId) throws NoSuchStateTableException {
		return remove((Serializable)stateId);
	}

	/**
	 * Removes the state table with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the state table
	 * @return the state table that was removed
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	@Override
	public StateTable remove(Serializable primaryKey)
		throws NoSuchStateTableException {

		Session session = null;

		try {
			session = openSession();

			StateTable stateTable = (StateTable)session.get(
				StateTableImpl.class, primaryKey);

			if (stateTable == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchStateTableException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(stateTable);
		}
		catch (NoSuchStateTableException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected StateTable removeImpl(StateTable stateTable) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(stateTable)) {
				stateTable = (StateTable)session.get(
					StateTableImpl.class, stateTable.getPrimaryKeyObj());
			}

			if (stateTable != null) {
				session.delete(stateTable);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (stateTable != null) {
			clearCache(stateTable);
		}

		return stateTable;
	}

	@Override
	public StateTable updateImpl(StateTable stateTable) {
		boolean isNew = stateTable.isNew();

		if (!(stateTable instanceof StateTableModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(stateTable.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(stateTable);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in stateTable proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom StateTable implementation " +
					stateTable.getClass());
		}

		StateTableModelImpl stateTableModelImpl =
			(StateTableModelImpl)stateTable;

		if (Validator.isNull(stateTable.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			stateTable.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(stateTable);

				stateTable.setNew(false);
			}
			else {
				stateTable = (StateTable)session.merge(stateTable);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (!_columnBitmaskEnabled) {
			finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}
		else if (isNew) {
			Object[] args = new Object[] {stateTableModelImpl.getUuid()};

			finderCache.removeResult(_finderPathCountByUuid, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByUuid, args);

			args = new Object[] {stateTableModelImpl.getCountry()};

			finderCache.removeResult(_finderPathCountByCountry, args);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindByCountry, args);

			finderCache.removeResult(_finderPathCountAll, FINDER_ARGS_EMPTY);
			finderCache.removeResult(
				_finderPathWithoutPaginationFindAll, FINDER_ARGS_EMPTY);
		}
		else {
			if ((stateTableModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByUuid.getColumnBitmask()) !=
					 0) {

				Object[] args = new Object[] {
					stateTableModelImpl.getOriginalUuid()
				};

				finderCache.removeResult(_finderPathCountByUuid, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByUuid, args);

				args = new Object[] {stateTableModelImpl.getUuid()};

				finderCache.removeResult(_finderPathCountByUuid, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByUuid, args);
			}

			if ((stateTableModelImpl.getColumnBitmask() &
				 _finderPathWithoutPaginationFindByCountry.
					 getColumnBitmask()) != 0) {

				Object[] args = new Object[] {
					stateTableModelImpl.getOriginalCountry()
				};

				finderCache.removeResult(_finderPathCountByCountry, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCountry, args);

				args = new Object[] {stateTableModelImpl.getCountry()};

				finderCache.removeResult(_finderPathCountByCountry, args);
				finderCache.removeResult(
					_finderPathWithoutPaginationFindByCountry, args);
			}
		}

		entityCache.putResult(
			entityCacheEnabled, StateTableImpl.class,
			stateTable.getPrimaryKey(), stateTable, false);

		stateTable.resetOriginalValues();

		return stateTable;
	}

	/**
	 * Returns the state table with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the state table
	 * @return the state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	@Override
	public StateTable findByPrimaryKey(Serializable primaryKey)
		throws NoSuchStateTableException {

		StateTable stateTable = fetchByPrimaryKey(primaryKey);

		if (stateTable == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchStateTableException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return stateTable;
	}

	/**
	 * Returns the state table with the primary key or throws a <code>NoSuchStateTableException</code> if it could not be found.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table
	 * @throws NoSuchStateTableException if a state table with the primary key could not be found
	 */
	@Override
	public StateTable findByPrimaryKey(long stateId)
		throws NoSuchStateTableException {

		return findByPrimaryKey((Serializable)stateId);
	}

	/**
	 * Returns the state table with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param stateId the primary key of the state table
	 * @return the state table, or <code>null</code> if a state table with the primary key could not be found
	 */
	@Override
	public StateTable fetchByPrimaryKey(long stateId) {
		return fetchByPrimaryKey((Serializable)stateId);
	}

	/**
	 * Returns all the state tables.
	 *
	 * @return the state tables
	 */
	@Override
	public List<StateTable> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @return the range of state tables
	 */
	@Override
	public List<StateTable> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of state tables
	 */
	@Override
	public List<StateTable> findAll(
		int start, int end, OrderByComparator<StateTable> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the state tables.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>StateTableModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of state tables
	 * @param end the upper bound of the range of state tables (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of state tables
	 */
	@Override
	public List<StateTable> findAll(
		int start, int end, OrderByComparator<StateTable> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<StateTable> list = null;

		if (useFinderCache) {
			list = (List<StateTable>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_STATETABLE);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_STATETABLE;

				sql = sql.concat(StateTableModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<StateTable>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				if (useFinderCache) {
					finderCache.removeResult(finderPath, finderArgs);
				}

				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the state tables from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (StateTable stateTable : findAll()) {
			remove(stateTable);
		}
	}

	/**
	 * Returns the number of state tables.
	 *
	 * @return the number of state tables
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_STATETABLE);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				finderCache.removeResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY);

				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "stateId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_STATETABLE;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return StateTableModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the state table persistence.
	 */
	@Activate
	public void activate() {
		StateTableModelImpl.setEntityCacheEnabled(entityCacheEnabled);
		StateTableModelImpl.setFinderCacheEnabled(finderCacheEnabled);

		_finderPathWithPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, StateTableImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, StateTableImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll",
			new String[0]);

		_finderPathCountAll = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0]);

		_finderPathWithPaginationFindByUuid = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, StateTableImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByUuid = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, StateTableImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] {String.class.getName()},
			StateTableModelImpl.UUID_COLUMN_BITMASK);

		_finderPathCountByUuid = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] {String.class.getName()});

		_finderPathWithPaginationFindByCountry = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, StateTableImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCountry",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			});

		_finderPathWithoutPaginationFindByCountry = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, StateTableImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCountry",
			new String[] {String.class.getName()},
			StateTableModelImpl.COUNTRY_COLUMN_BITMASK);

		_finderPathCountByCountry = new FinderPath(
			entityCacheEnabled, finderCacheEnabled, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCountry",
			new String[] {String.class.getName()});
	}

	@Deactivate
	public void deactivate() {
		entityCache.removeCache(StateTableImpl.class.getName());

		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	@Reference(
		target = FOOPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
		super.setConfiguration(configuration);

		_columnBitmaskEnabled = GetterUtil.getBoolean(
			configuration.get(
				"value.object.column.bitmask.enabled.com.country.service.model.StateTable"),
			true);
	}

	@Override
	@Reference(
		target = FOOPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = FOOPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private boolean _columnBitmaskEnabled;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_STATETABLE =
		"SELECT stateTable FROM StateTable stateTable";

	private static final String _SQL_SELECT_STATETABLE_WHERE =
		"SELECT stateTable FROM StateTable stateTable WHERE ";

	private static final String _SQL_COUNT_STATETABLE =
		"SELECT COUNT(stateTable) FROM StateTable stateTable";

	private static final String _SQL_COUNT_STATETABLE_WHERE =
		"SELECT COUNT(stateTable) FROM StateTable stateTable WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "stateTable.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No StateTable exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No StateTable exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		StateTablePersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"uuid", "state"});

}