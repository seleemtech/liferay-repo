package com.emp.records.portlet;

import com.country.service.model.StateTable;
import com.country.service.service.StateTableLocalServiceUtil;
import com.emp.records.constants.EmployeeRecordsPortletKeys;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author parameshwaran
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=EmployeeRecords", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/add.jsp",
		"javax.portlet.name=" + EmployeeRecordsPortletKeys.EMPLOYEERECORDS,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class EmployeeRecordsPortlet extends MVCPortlet {
	/*
	 * @ProcessAction(name="addEmployee") public void addEmployee(ActionRequest
	 * actionRequest, ActionResponse actionResponse) { long
	 * employeeId=ParamUtil.getLong(actionRequest,"employeeId");
	 * 
	 * }
	 */
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		String stateList = "";
		long stateId = 0L;
		long countryId = ParamUtil.getLong(resourceRequest, "countryId");
		String country = ParamUtil.getString(resourceRequest, "country");
		String countrySelected = ParamUtil.getString(resourceRequest, "countrySelected");

		JSONArray jsonArray = JSONFactoryUtil.createJSONArray();

		if (countrySelected.equalsIgnoreCase("countrySelected")) {
			try {
				List<StateTable> stateTableLi = StateTableLocalServiceUtil.getByCountry(country);

				for (StateTable stateTList : stateTableLi) {
					stateList = stateTList.getState();
					stateId = stateTList.getStateId();
					
					JSONObject jsonObject = JSONFactoryUtil.createJSONObject();

					jsonObject.put("stateList", stateList);
					jsonObject.put("stateId", stateId);
					jsonArray.put(jsonObject);
				}

			} catch (SystemException e) {
				e.printStackTrace();
			}
		}
		PrintWriter writer = resourceResponse.getWriter();
		writer.write(jsonArray.toString());
		writer.flush();
	}

}