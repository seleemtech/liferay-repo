package com.emp.records.constants;

/**
 * @author parameshwaran
 */
public class EmployeeRecordsPortletKeys {

	public static final String EMPLOYEERECORDS =
		"com_emp_records_EmployeeRecordsPortlet";

}