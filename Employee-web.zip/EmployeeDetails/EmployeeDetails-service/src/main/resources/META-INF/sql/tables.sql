create table FOO_EmployeeLeaveDetails (
	uuid_ VARCHAR(75) null,
	employeeId LONG not null primary key,
	employeeName VARCHAR(75) null,
	absenceType VARCHAR(75) null,
	startDate DATE null,
	endDate DATE null,
	applyingForDays LONG,
	leaveReason VARCHAR(75) null,
	companyId LONG,
	userId LONG
);