/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package EmployeeDetails.model.impl;

import EmployeeDetails.model.EmployeeLeaveDetails;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EmployeeLeaveDetails in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class EmployeeLeaveDetailsCacheModel
	implements CacheModel<EmployeeLeaveDetails>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EmployeeLeaveDetailsCacheModel)) {
			return false;
		}

		EmployeeLeaveDetailsCacheModel employeeLeaveDetailsCacheModel =
			(EmployeeLeaveDetailsCacheModel)object;

		if (employeeId == employeeLeaveDetailsCacheModel.employeeId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, employeeId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", employeeId=");
		sb.append(employeeId);
		sb.append(", employeeName=");
		sb.append(employeeName);
		sb.append(", absenceType=");
		sb.append(absenceType);
		sb.append(", startDate=");
		sb.append(startDate);
		sb.append(", endDate=");
		sb.append(endDate);
		sb.append(", applyingForDays=");
		sb.append(applyingForDays);
		sb.append(", leaveReason=");
		sb.append(leaveReason);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EmployeeLeaveDetails toEntityModel() {
		EmployeeLeaveDetailsImpl employeeLeaveDetailsImpl =
			new EmployeeLeaveDetailsImpl();

		if (uuid == null) {
			employeeLeaveDetailsImpl.setUuid("");
		}
		else {
			employeeLeaveDetailsImpl.setUuid(uuid);
		}

		employeeLeaveDetailsImpl.setEmployeeId(employeeId);

		if (employeeName == null) {
			employeeLeaveDetailsImpl.setEmployeeName("");
		}
		else {
			employeeLeaveDetailsImpl.setEmployeeName(employeeName);
		}

		if (absenceType == null) {
			employeeLeaveDetailsImpl.setAbsenceType("");
		}
		else {
			employeeLeaveDetailsImpl.setAbsenceType(absenceType);
		}

		if (startDate == Long.MIN_VALUE) {
			employeeLeaveDetailsImpl.setStartDate(null);
		}
		else {
			employeeLeaveDetailsImpl.setStartDate(new Date(startDate));
		}

		if (endDate == Long.MIN_VALUE) {
			employeeLeaveDetailsImpl.setEndDate(null);
		}
		else {
			employeeLeaveDetailsImpl.setEndDate(new Date(endDate));
		}

		employeeLeaveDetailsImpl.setApplyingForDays(applyingForDays);

		if (leaveReason == null) {
			employeeLeaveDetailsImpl.setLeaveReason("");
		}
		else {
			employeeLeaveDetailsImpl.setLeaveReason(leaveReason);
		}

		employeeLeaveDetailsImpl.setCompanyId(companyId);
		employeeLeaveDetailsImpl.setUserId(userId);

		employeeLeaveDetailsImpl.resetOriginalValues();

		return employeeLeaveDetailsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		employeeId = objectInput.readLong();
		employeeName = objectInput.readUTF();
		absenceType = objectInput.readUTF();
		startDate = objectInput.readLong();
		endDate = objectInput.readLong();

		applyingForDays = objectInput.readLong();
		leaveReason = objectInput.readUTF();

		companyId = objectInput.readLong();

		userId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(employeeId);

		if (employeeName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(employeeName);
		}

		if (absenceType == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(absenceType);
		}

		objectOutput.writeLong(startDate);
		objectOutput.writeLong(endDate);

		objectOutput.writeLong(applyingForDays);

		if (leaveReason == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(leaveReason);
		}

		objectOutput.writeLong(companyId);

		objectOutput.writeLong(userId);
	}

	public String uuid;
	public long employeeId;
	public String employeeName;
	public String absenceType;
	public long startDate;
	public long endDate;
	public long applyingForDays;
	public String leaveReason;
	public long companyId;
	public long userId;

}