/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package EmployeeDetails.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EmployeeLeaveDetails}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EmployeeLeaveDetails
 * @generated
 */
public class EmployeeLeaveDetailsWrapper
	extends BaseModelWrapper<EmployeeLeaveDetails>
	implements EmployeeLeaveDetails, ModelWrapper<EmployeeLeaveDetails> {

	public EmployeeLeaveDetailsWrapper(
		EmployeeLeaveDetails employeeLeaveDetails) {

		super(employeeLeaveDetails);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("employeeId", getEmployeeId());
		attributes.put("employeeName", getEmployeeName());
		attributes.put("absenceType", getAbsenceType());
		attributes.put("startDate", getStartDate());
		attributes.put("endDate", getEndDate());
		attributes.put("applyingForDays", getApplyingForDays());
		attributes.put("leaveReason", getLeaveReason());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long employeeId = (Long)attributes.get("employeeId");

		if (employeeId != null) {
			setEmployeeId(employeeId);
		}

		String employeeName = (String)attributes.get("employeeName");

		if (employeeName != null) {
			setEmployeeName(employeeName);
		}

		String absenceType = (String)attributes.get("absenceType");

		if (absenceType != null) {
			setAbsenceType(absenceType);
		}

		Date startDate = (Date)attributes.get("startDate");

		if (startDate != null) {
			setStartDate(startDate);
		}

		Date endDate = (Date)attributes.get("endDate");

		if (endDate != null) {
			setEndDate(endDate);
		}

		Long applyingForDays = (Long)attributes.get("applyingForDays");

		if (applyingForDays != null) {
			setApplyingForDays(applyingForDays);
		}

		String leaveReason = (String)attributes.get("leaveReason");

		if (leaveReason != null) {
			setLeaveReason(leaveReason);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}
	}

	/**
	 * Returns the absence type of this employee leave details.
	 *
	 * @return the absence type of this employee leave details
	 */
	@Override
	public String getAbsenceType() {
		return model.getAbsenceType();
	}

	/**
	 * Returns the applying for days of this employee leave details.
	 *
	 * @return the applying for days of this employee leave details
	 */
	@Override
	public long getApplyingForDays() {
		return model.getApplyingForDays();
	}

	/**
	 * Returns the company ID of this employee leave details.
	 *
	 * @return the company ID of this employee leave details
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the employee ID of this employee leave details.
	 *
	 * @return the employee ID of this employee leave details
	 */
	@Override
	public long getEmployeeId() {
		return model.getEmployeeId();
	}

	/**
	 * Returns the employee name of this employee leave details.
	 *
	 * @return the employee name of this employee leave details
	 */
	@Override
	public String getEmployeeName() {
		return model.getEmployeeName();
	}

	/**
	 * Returns the end date of this employee leave details.
	 *
	 * @return the end date of this employee leave details
	 */
	@Override
	public Date getEndDate() {
		return model.getEndDate();
	}

	/**
	 * Returns the leave reason of this employee leave details.
	 *
	 * @return the leave reason of this employee leave details
	 */
	@Override
	public String getLeaveReason() {
		return model.getLeaveReason();
	}

	/**
	 * Returns the primary key of this employee leave details.
	 *
	 * @return the primary key of this employee leave details
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the start date of this employee leave details.
	 *
	 * @return the start date of this employee leave details
	 */
	@Override
	public Date getStartDate() {
		return model.getStartDate();
	}

	/**
	 * Returns the user ID of this employee leave details.
	 *
	 * @return the user ID of this employee leave details
	 */
	@Override
	public long getUserId() {
		return model.getUserId();
	}

	/**
	 * Returns the user uuid of this employee leave details.
	 *
	 * @return the user uuid of this employee leave details
	 */
	@Override
	public String getUserUuid() {
		return model.getUserUuid();
	}

	/**
	 * Returns the uuid of this employee leave details.
	 *
	 * @return the uuid of this employee leave details
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the absence type of this employee leave details.
	 *
	 * @param absenceType the absence type of this employee leave details
	 */
	@Override
	public void setAbsenceType(String absenceType) {
		model.setAbsenceType(absenceType);
	}

	/**
	 * Sets the applying for days of this employee leave details.
	 *
	 * @param applyingForDays the applying for days of this employee leave details
	 */
	@Override
	public void setApplyingForDays(long applyingForDays) {
		model.setApplyingForDays(applyingForDays);
	}

	/**
	 * Sets the company ID of this employee leave details.
	 *
	 * @param companyId the company ID of this employee leave details
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the employee ID of this employee leave details.
	 *
	 * @param employeeId the employee ID of this employee leave details
	 */
	@Override
	public void setEmployeeId(long employeeId) {
		model.setEmployeeId(employeeId);
	}

	/**
	 * Sets the employee name of this employee leave details.
	 *
	 * @param employeeName the employee name of this employee leave details
	 */
	@Override
	public void setEmployeeName(String employeeName) {
		model.setEmployeeName(employeeName);
	}

	/**
	 * Sets the end date of this employee leave details.
	 *
	 * @param endDate the end date of this employee leave details
	 */
	@Override
	public void setEndDate(Date endDate) {
		model.setEndDate(endDate);
	}

	/**
	 * Sets the leave reason of this employee leave details.
	 *
	 * @param leaveReason the leave reason of this employee leave details
	 */
	@Override
	public void setLeaveReason(String leaveReason) {
		model.setLeaveReason(leaveReason);
	}

	/**
	 * Sets the primary key of this employee leave details.
	 *
	 * @param primaryKey the primary key of this employee leave details
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the start date of this employee leave details.
	 *
	 * @param startDate the start date of this employee leave details
	 */
	@Override
	public void setStartDate(Date startDate) {
		model.setStartDate(startDate);
	}

	/**
	 * Sets the user ID of this employee leave details.
	 *
	 * @param userId the user ID of this employee leave details
	 */
	@Override
	public void setUserId(long userId) {
		model.setUserId(userId);
	}

	/**
	 * Sets the user uuid of this employee leave details.
	 *
	 * @param userUuid the user uuid of this employee leave details
	 */
	@Override
	public void setUserUuid(String userUuid) {
		model.setUserUuid(userUuid);
	}

	/**
	 * Sets the uuid of this employee leave details.
	 *
	 * @param uuid the uuid of this employee leave details
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected EmployeeLeaveDetailsWrapper wrap(
		EmployeeLeaveDetails employeeLeaveDetails) {

		return new EmployeeLeaveDetailsWrapper(employeeLeaveDetails);
	}

}