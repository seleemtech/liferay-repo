package com.employee.web.portlet;

import com.employee.service.exception.NoSuchEmployeeException;
import com.employee.service.model.Employee;
import com.employee.service.service.EmployeeLocalService;
import com.employee.service.service.EmployeeLocalServiceUtil;
import com.employee.web.constants.EmployeeWebPortletKeys;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Projection;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionList;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletClassLoaderUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DELL
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=EmployeeWeb", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp", "javax.portlet.name=" + EmployeeWebPortletKeys.EMPLOYEEWEB,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class EmployeeWebPortlet extends MVCPortlet {
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {

		long empId = ParamUtil.getLong(renderRequest, "empId");
		List<Employee> emp = EmployeeLocalServiceUtil.getEmployees(-1, -1);

		ClassLoader classloader = getClass().getClassLoader();

		/*
		 * DynamicQuery dynamicquery = DynamicQueryFactoryUtil.forClass(Employee.class,
		 * classloader);
		 * dynamicquery.add(PropertyFactoryUtil.forName("empAddress").eq("somthing"));
		 * List<Employee> dynlist = EmployeeLocalServiceUtil.dynamicQuery(dynamicquery);
		 * System.out.println(dynlist);
		 */

		/*
		 * DynamicQuery
		 * dynamicQuery=DynamicQueryFactoryUtil.forClass(Employee.class,classloader);
		 * Projection
		 * projection=ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property(
		 * "empName")); dynamicQuery.setProjection(projection); List<Employee>
		 * dynlist=EmployeeLocalServiceUtil.dynamicQuery(dynamicQuery);
		 * System.out.println(dynlist);
		 */

		/*
		 * DynamicQuery
		 * dynamicQuery=DynamicQueryFactoryUtil.forClass(Employee.class,classloader);
		 * ProjectionList projectionlist=ProjectionFactoryUtil.projectionList();
		 * projectionlist.add(PropertyFactoryUtil.forName("empName"));
		 * projectionlist.add(PropertyFactoryUtil.forName("empId"));
		 * dynamicQuery.setProjection(projectionlist);
		 * 
		 * List<Employee> dynlist =EmployeeLocalServiceUtil.dynamicQuery(dynamicQuery);
		 * System.out.println(dynlist);
		 */

		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(Employee.class, classloader);
		Criterion criterion = null;
		criterion = RestrictionsFactoryUtil.eq("empAddress", "somthing");
		criterion = RestrictionsFactoryUtil.and(criterion, RestrictionsFactoryUtil.eq("empId", new Long(37613)));
		Projection projection=ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property("empName"));
		
		dynamicQuery.add(criterion);
		dynamicQuery.setProjection(projection);
		List<Employee> dylist = EmployeeLocalServiceUtil.dynamicQuery(dynamicQuery);
		System.out.println(dylist);

		if (empId > 0) {
			Employee employee = null;
			try {

				employee = EmployeeLocalServiceUtil.getEmployee(empId);
			} catch (Exception e) {
				// TODO: handle exception
			}
			renderRequest.setAttribute("employee", employee);
		}
		renderRequest.setAttribute("empId", empId);
		renderRequest.setAttribute("emp", emp);

		super.render(renderRequest, renderResponse);
	}

	public void updateEmployee(ActionRequest actionRequest, ActionResponse actionResponse)

	{
		long empId = ParamUtil.getLong(actionRequest, "empId");
		String empName = ParamUtil.getString(actionRequest, "empName");
		String empAddress = ParamUtil.getString(actionRequest, "empAddress");
		long empNo = ParamUtil.getLong(actionRequest, "empNo");
		if (empId > 0) {
			try {
				_employeeLocalService.updateEmployee(empId, empName, empAddress, empNo);

				actionResponse.setRenderParameter("empId", Long.toString(empId));
			} catch (NoSuchEmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		} else {
			try {
				_employeeLocalService.add(empName, empAddress, empNo);
				actionResponse.setRenderParameter("empId", Long.toString(empId));
			} catch (Exception e) {
				System.out.println(e);

				// TODO: handle exception
			}
		}
	}

	public void deleteEmployee(ActionRequest actionRequest, ActionResponse actionResponse) {
		long empId = ParamUtil.getLong(actionRequest, "empId");
		try {

			_employeeLocalService.deleteEmployee(empId);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Reference
	private EmployeeLocalService _employeeLocalService;

}