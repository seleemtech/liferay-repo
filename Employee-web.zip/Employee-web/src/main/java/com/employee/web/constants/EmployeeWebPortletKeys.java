package com.employee.web.constants;

/**
 * @author DELL
 */
public class EmployeeWebPortletKeys {

	public static final String EMPLOYEEWEB =
		"com_employee_web_EmployeeWebPortlet";

}