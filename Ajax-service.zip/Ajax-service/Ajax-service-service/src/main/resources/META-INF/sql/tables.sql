create table FOO_Country (
	uuid_ VARCHAR(75) null,
	countryId LONG not null primary key,
	country VARCHAR(75) null
);

create table FOO_State (
	stateId LONG not null primary key,
	country VARCHAR(75) null,
	stateName VARCHAR(75) null
);