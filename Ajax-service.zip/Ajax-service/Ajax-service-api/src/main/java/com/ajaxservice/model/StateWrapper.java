/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ajaxservice.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link State}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see State
 * @generated
 */
public class StateWrapper
	extends BaseModelWrapper<State> implements ModelWrapper<State>, State {

	public StateWrapper(State state) {
		super(state);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("stateId", getStateId());
		attributes.put("country", getCountry());
		attributes.put("stateName", getStateName());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long stateId = (Long)attributes.get("stateId");

		if (stateId != null) {
			setStateId(stateId);
		}

		String country = (String)attributes.get("country");

		if (country != null) {
			setCountry(country);
		}

		String stateName = (String)attributes.get("stateName");

		if (stateName != null) {
			setStateName(stateName);
		}
	}

	/**
	 * Returns the country of this state.
	 *
	 * @return the country of this state
	 */
	@Override
	public String getCountry() {
		return model.getCountry();
	}

	/**
	 * Returns the primary key of this state.
	 *
	 * @return the primary key of this state
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the state ID of this state.
	 *
	 * @return the state ID of this state
	 */
	@Override
	public long getStateId() {
		return model.getStateId();
	}

	/**
	 * Returns the state name of this state.
	 *
	 * @return the state name of this state
	 */
	@Override
	public String getStateName() {
		return model.getStateName();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the country of this state.
	 *
	 * @param country the country of this state
	 */
	@Override
	public void setCountry(String country) {
		model.setCountry(country);
	}

	/**
	 * Sets the primary key of this state.
	 *
	 * @param primaryKey the primary key of this state
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the state ID of this state.
	 *
	 * @param stateId the state ID of this state
	 */
	@Override
	public void setStateId(long stateId) {
		model.setStateId(stateId);
	}

	/**
	 * Sets the state name of this state.
	 *
	 * @param stateName the state name of this state
	 */
	@Override
	public void setStateName(String stateName) {
		model.setStateName(stateName);
	}

	@Override
	protected StateWrapper wrap(State state) {
		return new StateWrapper(state);
	}

}