package com.ajax.constants;

/**
 * @author DELL
 */
public class AjaxPortletKeys {

	public static final String AJAX =
		"com_ajax_AjaxPortlet";

}