/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.docterservice.model.impl;

import com.docterservice.model.Docter;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Docter in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class DocterCacheModel implements CacheModel<Docter>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof DocterCacheModel)) {
			return false;
		}

		DocterCacheModel docterCacheModel = (DocterCacheModel)object;

		if (docterId == docterCacheModel.docterId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, docterId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{docterId=");
		sb.append(docterId);
		sb.append(", docterName=");
		sb.append(docterName);
		sb.append(", docterQual=");
		sb.append(docterQual);
		sb.append(", docterAdd=");
		sb.append(docterAdd);
		sb.append(", ContactNo=");
		sb.append(ContactNo);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Docter toEntityModel() {
		DocterImpl docterImpl = new DocterImpl();

		docterImpl.setDocterId(docterId);

		if (docterName == null) {
			docterImpl.setDocterName("");
		}
		else {
			docterImpl.setDocterName(docterName);
		}

		if (docterQual == null) {
			docterImpl.setDocterQual("");
		}
		else {
			docterImpl.setDocterQual(docterQual);
		}

		if (docterAdd == null) {
			docterImpl.setDocterAdd("");
		}
		else {
			docterImpl.setDocterAdd(docterAdd);
		}

		docterImpl.setContactNo(ContactNo);

		docterImpl.resetOriginalValues();

		return docterImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		docterId = objectInput.readLong();
		docterName = objectInput.readUTF();
		docterQual = objectInput.readUTF();
		docterAdd = objectInput.readUTF();

		ContactNo = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(docterId);

		if (docterName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(docterName);
		}

		if (docterQual == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(docterQual);
		}

		if (docterAdd == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(docterAdd);
		}

		objectOutput.writeLong(ContactNo);
	}

	public long docterId;
	public String docterName;
	public String docterQual;
	public String docterAdd;
	public long ContactNo;

}