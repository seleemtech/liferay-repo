create table FOO_Docter (
	docterId LONG not null primary key,
	docterName VARCHAR(75) null,
	docterQual VARCHAR(75) null,
	docterAdd VARCHAR(75) null,
	ContactNo LONG
);