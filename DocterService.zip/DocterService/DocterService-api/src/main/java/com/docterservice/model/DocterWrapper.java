/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.docterservice.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Docter}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Docter
 * @generated
 */
public class DocterWrapper
	extends BaseModelWrapper<Docter> implements Docter, ModelWrapper<Docter> {

	public DocterWrapper(Docter docter) {
		super(docter);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("docterId", getDocterId());
		attributes.put("docterName", getDocterName());
		attributes.put("docterQual", getDocterQual());
		attributes.put("docterAdd", getDocterAdd());
		attributes.put("ContactNo", getContactNo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long docterId = (Long)attributes.get("docterId");

		if (docterId != null) {
			setDocterId(docterId);
		}

		String docterName = (String)attributes.get("docterName");

		if (docterName != null) {
			setDocterName(docterName);
		}

		String docterQual = (String)attributes.get("docterQual");

		if (docterQual != null) {
			setDocterQual(docterQual);
		}

		String docterAdd = (String)attributes.get("docterAdd");

		if (docterAdd != null) {
			setDocterAdd(docterAdd);
		}

		Long ContactNo = (Long)attributes.get("ContactNo");

		if (ContactNo != null) {
			setContactNo(ContactNo);
		}
	}

	/**
	 * Returns the contact no of this docter.
	 *
	 * @return the contact no of this docter
	 */
	@Override
	public long getContactNo() {
		return model.getContactNo();
	}

	/**
	 * Returns the docter add of this docter.
	 *
	 * @return the docter add of this docter
	 */
	@Override
	public String getDocterAdd() {
		return model.getDocterAdd();
	}

	/**
	 * Returns the docter ID of this docter.
	 *
	 * @return the docter ID of this docter
	 */
	@Override
	public long getDocterId() {
		return model.getDocterId();
	}

	/**
	 * Returns the docter name of this docter.
	 *
	 * @return the docter name of this docter
	 */
	@Override
	public String getDocterName() {
		return model.getDocterName();
	}

	/**
	 * Returns the docter qual of this docter.
	 *
	 * @return the docter qual of this docter
	 */
	@Override
	public String getDocterQual() {
		return model.getDocterQual();
	}

	/**
	 * Returns the primary key of this docter.
	 *
	 * @return the primary key of this docter
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the contact no of this docter.
	 *
	 * @param ContactNo the contact no of this docter
	 */
	@Override
	public void setContactNo(long ContactNo) {
		model.setContactNo(ContactNo);
	}

	/**
	 * Sets the docter add of this docter.
	 *
	 * @param docterAdd the docter add of this docter
	 */
	@Override
	public void setDocterAdd(String docterAdd) {
		model.setDocterAdd(docterAdd);
	}

	/**
	 * Sets the docter ID of this docter.
	 *
	 * @param docterId the docter ID of this docter
	 */
	@Override
	public void setDocterId(long docterId) {
		model.setDocterId(docterId);
	}

	/**
	 * Sets the docter name of this docter.
	 *
	 * @param docterName the docter name of this docter
	 */
	@Override
	public void setDocterName(String docterName) {
		model.setDocterName(docterName);
	}

	/**
	 * Sets the docter qual of this docter.
	 *
	 * @param docterQual the docter qual of this docter
	 */
	@Override
	public void setDocterQual(String docterQual) {
		model.setDocterQual(docterQual);
	}

	/**
	 * Sets the primary key of this docter.
	 *
	 * @param primaryKey the primary key of this docter
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	@Override
	protected DocterWrapper wrap(Docter docter) {
		return new DocterWrapper(docter);
	}

}