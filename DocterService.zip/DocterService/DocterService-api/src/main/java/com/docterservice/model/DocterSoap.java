/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.docterservice.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.docterservice.service.http.DocterServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class DocterSoap implements Serializable {

	public static DocterSoap toSoapModel(Docter model) {
		DocterSoap soapModel = new DocterSoap();

		soapModel.setDocterId(model.getDocterId());
		soapModel.setDocterName(model.getDocterName());
		soapModel.setDocterQual(model.getDocterQual());
		soapModel.setDocterAdd(model.getDocterAdd());
		soapModel.setContactNo(model.getContactNo());

		return soapModel;
	}

	public static DocterSoap[] toSoapModels(Docter[] models) {
		DocterSoap[] soapModels = new DocterSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static DocterSoap[][] toSoapModels(Docter[][] models) {
		DocterSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new DocterSoap[models.length][models[0].length];
		}
		else {
			soapModels = new DocterSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static DocterSoap[] toSoapModels(List<Docter> models) {
		List<DocterSoap> soapModels = new ArrayList<DocterSoap>(models.size());

		for (Docter model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new DocterSoap[soapModels.size()]);
	}

	public DocterSoap() {
	}

	public long getPrimaryKey() {
		return _docterId;
	}

	public void setPrimaryKey(long pk) {
		setDocterId(pk);
	}

	public long getDocterId() {
		return _docterId;
	}

	public void setDocterId(long docterId) {
		_docterId = docterId;
	}

	public String getDocterName() {
		return _docterName;
	}

	public void setDocterName(String docterName) {
		_docterName = docterName;
	}

	public String getDocterQual() {
		return _docterQual;
	}

	public void setDocterQual(String docterQual) {
		_docterQual = docterQual;
	}

	public String getDocterAdd() {
		return _docterAdd;
	}

	public void setDocterAdd(String docterAdd) {
		_docterAdd = docterAdd;
	}

	public long getContactNo() {
		return _ContactNo;
	}

	public void setContactNo(long ContactNo) {
		_ContactNo = ContactNo;
	}

	private long _docterId;
	private String _docterName;
	private String _docterQual;
	private String _docterAdd;
	private long _ContactNo;

}