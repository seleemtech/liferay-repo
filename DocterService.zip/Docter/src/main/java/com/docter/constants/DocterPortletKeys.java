package com.docter.constants;

/**
 * @author DELL
 */
public class DocterPortletKeys {

	public static final String DOCTER =
		"com_docter_DocterPortlet";

}