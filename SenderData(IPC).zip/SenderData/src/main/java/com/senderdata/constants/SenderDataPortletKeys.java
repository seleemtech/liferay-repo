package com.senderdata.constants;

/**
 * @author DELL
 */
public class SenderDataPortletKeys {

	public static final String SENDERDATA =
		"com_senderdata_SenderDataPortlet";

}