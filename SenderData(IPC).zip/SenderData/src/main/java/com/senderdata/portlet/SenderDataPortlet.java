package com.senderdata.portlet;

import com.addsenderdata.model.SenderData;
import com.addsenderdata.service.SenderDataLocalServiceUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.senderdata.constants.SenderDataPortletKeys;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;

import org.osgi.service.component.annotations.Component;



/**
 * @author DELL
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=SenderData", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp", "javax.portlet.name=" + SenderDataPortletKeys.SENDERDATA,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class SenderDataPortlet extends MVCPortlet {
	@ProcessAction(name = "sendData")
	public void sendData(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {
		long dataId = ParamUtil.getLong(actionRequest, "dataId");
		String dataName = ParamUtil.getString(actionRequest, "dataName");

		DateFormat ddmmyy = DateFormat.getDateInstance();
		Date dataDate = ParamUtil.getDate(actionRequest, "dataDate", ddmmyy);

		SenderData sd = null;
		sd = SenderDataLocalServiceUtil.createSenderData(dataId);
		sd.setDataId(dataId);
		sd.setDataName(dataName);
		sd.setDataDate(dataDate); 
		SenderDataLocalServiceUtil.addSenderData(sd);

		// TODO Auto-generated method stub
		super.processAction(actionRequest, actionResponse);
	}
}