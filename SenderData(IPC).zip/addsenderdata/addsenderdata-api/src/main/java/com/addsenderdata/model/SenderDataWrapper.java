/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.addsenderdata.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link SenderData}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see SenderData
 * @generated
 */
public class SenderDataWrapper
	extends BaseModelWrapper<SenderData>
	implements ModelWrapper<SenderData>, SenderData {

	public SenderDataWrapper(SenderData senderData) {
		super(senderData);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("dataId", getDataId());
		attributes.put("dataName", getDataName());
		attributes.put("dataDate", getDataDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long dataId = (Long)attributes.get("dataId");

		if (dataId != null) {
			setDataId(dataId);
		}

		String dataName = (String)attributes.get("dataName");

		if (dataName != null) {
			setDataName(dataName);
		}

		Date dataDate = (Date)attributes.get("dataDate");

		if (dataDate != null) {
			setDataDate(dataDate);
		}
	}

	/**
	 * Returns the data date of this sender data.
	 *
	 * @return the data date of this sender data
	 */
	@Override
	public Date getDataDate() {
		return model.getDataDate();
	}

	/**
	 * Returns the data ID of this sender data.
	 *
	 * @return the data ID of this sender data
	 */
	@Override
	public long getDataId() {
		return model.getDataId();
	}

	/**
	 * Returns the data name of this sender data.
	 *
	 * @return the data name of this sender data
	 */
	@Override
	public String getDataName() {
		return model.getDataName();
	}

	/**
	 * Returns the primary key of this sender data.
	 *
	 * @return the primary key of this sender data
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this sender data.
	 *
	 * @return the uuid of this sender data
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the data date of this sender data.
	 *
	 * @param dataDate the data date of this sender data
	 */
	@Override
	public void setDataDate(Date dataDate) {
		model.setDataDate(dataDate);
	}

	/**
	 * Sets the data ID of this sender data.
	 *
	 * @param dataId the data ID of this sender data
	 */
	@Override
	public void setDataId(long dataId) {
		model.setDataId(dataId);
	}

	/**
	 * Sets the data name of this sender data.
	 *
	 * @param dataName the data name of this sender data
	 */
	@Override
	public void setDataName(String dataName) {
		model.setDataName(dataName);
	}

	/**
	 * Sets the primary key of this sender data.
	 *
	 * @param primaryKey the primary key of this sender data
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this sender data.
	 *
	 * @param uuid the uuid of this sender data
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected SenderDataWrapper wrap(SenderData senderData) {
		return new SenderDataWrapper(senderData);
	}

}