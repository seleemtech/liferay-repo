/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.addsenderdata.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link SenderDataLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see SenderDataLocalService
 * @generated
 */
public class SenderDataLocalServiceWrapper
	implements SenderDataLocalService, ServiceWrapper<SenderDataLocalService> {

	public SenderDataLocalServiceWrapper(
		SenderDataLocalService senderDataLocalService) {

		_senderDataLocalService = senderDataLocalService;
	}

	/**
	 * Adds the sender data to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect SenderDataLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param senderData the sender data
	 * @return the sender data that was added
	 */
	@Override
	public com.addsenderdata.model.SenderData addSenderData(
		com.addsenderdata.model.SenderData senderData) {

		return _senderDataLocalService.addSenderData(senderData);
	}

	/**
	 * Creates a new sender data with the primary key. Does not add the sender data to the database.
	 *
	 * @param dataId the primary key for the new sender data
	 * @return the new sender data
	 */
	@Override
	public com.addsenderdata.model.SenderData createSenderData(long dataId) {
		return _senderDataLocalService.createSenderData(dataId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _senderDataLocalService.deletePersistedModel(persistedModel);
	}

	/**
	 * Deletes the sender data with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect SenderDataLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param dataId the primary key of the sender data
	 * @return the sender data that was removed
	 * @throws PortalException if a sender data with the primary key could not be found
	 */
	@Override
	public com.addsenderdata.model.SenderData deleteSenderData(long dataId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _senderDataLocalService.deleteSenderData(dataId);
	}

	/**
	 * Deletes the sender data from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect SenderDataLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param senderData the sender data
	 * @return the sender data that was removed
	 */
	@Override
	public com.addsenderdata.model.SenderData deleteSenderData(
		com.addsenderdata.model.SenderData senderData) {

		return _senderDataLocalService.deleteSenderData(senderData);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _senderDataLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _senderDataLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.addsenderdata.model.impl.SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _senderDataLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.addsenderdata.model.impl.SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _senderDataLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _senderDataLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _senderDataLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.addsenderdata.model.SenderData fetchSenderData(long dataId) {
		return _senderDataLocalService.fetchSenderData(dataId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _senderDataLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _senderDataLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _senderDataLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _senderDataLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Returns the sender data with the primary key.
	 *
	 * @param dataId the primary key of the sender data
	 * @return the sender data
	 * @throws PortalException if a sender data with the primary key could not be found
	 */
	@Override
	public com.addsenderdata.model.SenderData getSenderData(long dataId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _senderDataLocalService.getSenderData(dataId);
	}

	/**
	 * Returns a range of all the sender datas.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.addsenderdata.model.impl.SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @return the range of sender datas
	 */
	@Override
	public java.util.List<com.addsenderdata.model.SenderData> getSenderDatas(
		int start, int end) {

		return _senderDataLocalService.getSenderDatas(start, end);
	}

	/**
	 * Returns the number of sender datas.
	 *
	 * @return the number of sender datas
	 */
	@Override
	public int getSenderDatasCount() {
		return _senderDataLocalService.getSenderDatasCount();
	}

	/**
	 * Updates the sender data in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect SenderDataLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param senderData the sender data
	 * @return the sender data that was updated
	 */
	@Override
	public com.addsenderdata.model.SenderData updateSenderData(
		com.addsenderdata.model.SenderData senderData) {

		return _senderDataLocalService.updateSenderData(senderData);
	}

	@Override
	public SenderDataLocalService getWrappedService() {
		return _senderDataLocalService;
	}

	@Override
	public void setWrappedService(
		SenderDataLocalService senderDataLocalService) {

		_senderDataLocalService = senderDataLocalService;
	}

	private SenderDataLocalService _senderDataLocalService;

}