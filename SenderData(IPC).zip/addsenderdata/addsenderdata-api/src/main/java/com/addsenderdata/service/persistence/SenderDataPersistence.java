/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.addsenderdata.service.persistence;

import com.addsenderdata.exception.NoSuchSenderDataException;
import com.addsenderdata.model.SenderData;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the sender data service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see SenderDataUtil
 * @generated
 */
@ProviderType
public interface SenderDataPersistence extends BasePersistence<SenderData> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link SenderDataUtil} to access the sender data persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the sender datas where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching sender datas
	 */
	public java.util.List<SenderData> findByUuid(String uuid);

	/**
	 * Returns a range of all the sender datas where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @return the range of matching sender datas
	 */
	public java.util.List<SenderData> findByUuid(
		String uuid, int start, int end);

	/**
	 * Returns an ordered range of all the sender datas where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching sender datas
	 */
	public java.util.List<SenderData> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<SenderData>
			orderByComparator);

	/**
	 * Returns an ordered range of all the sender datas where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching sender datas
	 */
	public java.util.List<SenderData> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<SenderData>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first sender data in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sender data
	 * @throws NoSuchSenderDataException if a matching sender data could not be found
	 */
	public SenderData findByUuid_First(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<SenderData>
				orderByComparator)
		throws NoSuchSenderDataException;

	/**
	 * Returns the first sender data in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching sender data, or <code>null</code> if a matching sender data could not be found
	 */
	public SenderData fetchByUuid_First(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<SenderData>
			orderByComparator);

	/**
	 * Returns the last sender data in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sender data
	 * @throws NoSuchSenderDataException if a matching sender data could not be found
	 */
	public SenderData findByUuid_Last(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<SenderData>
				orderByComparator)
		throws NoSuchSenderDataException;

	/**
	 * Returns the last sender data in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching sender data, or <code>null</code> if a matching sender data could not be found
	 */
	public SenderData fetchByUuid_Last(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<SenderData>
			orderByComparator);

	/**
	 * Returns the sender datas before and after the current sender data in the ordered set where uuid = &#63;.
	 *
	 * @param dataId the primary key of the current sender data
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next sender data
	 * @throws NoSuchSenderDataException if a sender data with the primary key could not be found
	 */
	public SenderData[] findByUuid_PrevAndNext(
			long dataId, String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<SenderData>
				orderByComparator)
		throws NoSuchSenderDataException;

	/**
	 * Removes all the sender datas where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public void removeByUuid(String uuid);

	/**
	 * Returns the number of sender datas where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching sender datas
	 */
	public int countByUuid(String uuid);

	/**
	 * Caches the sender data in the entity cache if it is enabled.
	 *
	 * @param senderData the sender data
	 */
	public void cacheResult(SenderData senderData);

	/**
	 * Caches the sender datas in the entity cache if it is enabled.
	 *
	 * @param senderDatas the sender datas
	 */
	public void cacheResult(java.util.List<SenderData> senderDatas);

	/**
	 * Creates a new sender data with the primary key. Does not add the sender data to the database.
	 *
	 * @param dataId the primary key for the new sender data
	 * @return the new sender data
	 */
	public SenderData create(long dataId);

	/**
	 * Removes the sender data with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param dataId the primary key of the sender data
	 * @return the sender data that was removed
	 * @throws NoSuchSenderDataException if a sender data with the primary key could not be found
	 */
	public SenderData remove(long dataId) throws NoSuchSenderDataException;

	public SenderData updateImpl(SenderData senderData);

	/**
	 * Returns the sender data with the primary key or throws a <code>NoSuchSenderDataException</code> if it could not be found.
	 *
	 * @param dataId the primary key of the sender data
	 * @return the sender data
	 * @throws NoSuchSenderDataException if a sender data with the primary key could not be found
	 */
	public SenderData findByPrimaryKey(long dataId)
		throws NoSuchSenderDataException;

	/**
	 * Returns the sender data with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param dataId the primary key of the sender data
	 * @return the sender data, or <code>null</code> if a sender data with the primary key could not be found
	 */
	public SenderData fetchByPrimaryKey(long dataId);

	/**
	 * Returns all the sender datas.
	 *
	 * @return the sender datas
	 */
	public java.util.List<SenderData> findAll();

	/**
	 * Returns a range of all the sender datas.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @return the range of sender datas
	 */
	public java.util.List<SenderData> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the sender datas.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of sender datas
	 */
	public java.util.List<SenderData> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<SenderData>
			orderByComparator);

	/**
	 * Returns an ordered range of all the sender datas.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>SenderDataModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of sender datas
	 * @param end the upper bound of the range of sender datas (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of sender datas
	 */
	public java.util.List<SenderData> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<SenderData>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the sender datas from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of sender datas.
	 *
	 * @return the number of sender datas
	 */
	public int countAll();

}