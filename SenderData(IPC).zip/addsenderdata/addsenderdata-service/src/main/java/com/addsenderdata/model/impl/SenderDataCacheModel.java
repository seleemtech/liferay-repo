/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.addsenderdata.model.impl;

import com.addsenderdata.model.SenderData;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing SenderData in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class SenderDataCacheModel
	implements CacheModel<SenderData>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof SenderDataCacheModel)) {
			return false;
		}

		SenderDataCacheModel senderDataCacheModel =
			(SenderDataCacheModel)object;

		if (dataId == senderDataCacheModel.dataId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, dataId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", dataId=");
		sb.append(dataId);
		sb.append(", dataName=");
		sb.append(dataName);
		sb.append(", dataDate=");
		sb.append(dataDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SenderData toEntityModel() {
		SenderDataImpl senderDataImpl = new SenderDataImpl();

		if (uuid == null) {
			senderDataImpl.setUuid("");
		}
		else {
			senderDataImpl.setUuid(uuid);
		}

		senderDataImpl.setDataId(dataId);

		if (dataName == null) {
			senderDataImpl.setDataName("");
		}
		else {
			senderDataImpl.setDataName(dataName);
		}

		if (dataDate == Long.MIN_VALUE) {
			senderDataImpl.setDataDate(null);
		}
		else {
			senderDataImpl.setDataDate(new Date(dataDate));
		}

		senderDataImpl.resetOriginalValues();

		return senderDataImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		dataId = objectInput.readLong();
		dataName = objectInput.readUTF();
		dataDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(dataId);

		if (dataName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(dataName);
		}

		objectOutput.writeLong(dataDate);
	}

	public String uuid;
	public long dataId;
	public String dataName;
	public long dataDate;

}