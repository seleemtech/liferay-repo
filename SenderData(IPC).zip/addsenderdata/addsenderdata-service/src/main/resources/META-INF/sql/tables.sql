create table FOO_SenderData (
	uuid_ VARCHAR(75) null,
	dataId LONG not null primary key,
	dataName VARCHAR(75) null,
	dataDate DATE null
);