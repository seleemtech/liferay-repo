/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package complianceservice.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import complianceservice.model.Compliance;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Compliance in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ComplianceCacheModel
	implements CacheModel<Compliance>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ComplianceCacheModel)) {
			return false;
		}

		ComplianceCacheModel complianceCacheModel =
			(ComplianceCacheModel)object;

		if (complianceId == complianceCacheModel.complianceId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, complianceId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{complianceId=");
		sb.append(complianceId);
		sb.append(", complianceName=");
		sb.append(complianceName);
		sb.append(", complianceColor=");
		sb.append(complianceColor);
		sb.append(", complianceNumber=");
		sb.append(complianceNumber);
		sb.append(", contactNumber=");
		sb.append(contactNumber);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Compliance toEntityModel() {
		ComplianceImpl complianceImpl = new ComplianceImpl();

		complianceImpl.setComplianceId(complianceId);

		if (complianceName == null) {
			complianceImpl.setComplianceName("");
		}
		else {
			complianceImpl.setComplianceName(complianceName);
		}

		if (complianceColor == null) {
			complianceImpl.setComplianceColor("");
		}
		else {
			complianceImpl.setComplianceColor(complianceColor);
		}

		complianceImpl.setComplianceNumber(complianceNumber);
		complianceImpl.setContactNumber(contactNumber);

		complianceImpl.resetOriginalValues();

		return complianceImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		complianceId = objectInput.readLong();
		complianceName = objectInput.readUTF();
		complianceColor = objectInput.readUTF();

		complianceNumber = objectInput.readLong();

		contactNumber = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(complianceId);

		if (complianceName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(complianceName);
		}

		if (complianceColor == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(complianceColor);
		}

		objectOutput.writeLong(complianceNumber);

		objectOutput.writeLong(contactNumber);
	}

	public long complianceId;
	public String complianceName;
	public String complianceColor;
	public long complianceNumber;
	public long contactNumber;

}