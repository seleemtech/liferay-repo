create table FOO_Compliance (
	complianceId LONG not null primary key,
	complianceName VARCHAR(75) null,
	complianceColor VARCHAR(75) null,
	complianceNumber LONG,
	contactNumber LONG
);