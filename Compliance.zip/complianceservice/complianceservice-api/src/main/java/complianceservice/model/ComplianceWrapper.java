/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package complianceservice.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Compliance}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Compliance
 * @generated
 */
public class ComplianceWrapper
	extends BaseModelWrapper<Compliance>
	implements Compliance, ModelWrapper<Compliance> {

	public ComplianceWrapper(Compliance compliance) {
		super(compliance);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("complianceId", getComplianceId());
		attributes.put("complianceName", getComplianceName());
		attributes.put("complianceColor", getComplianceColor());
		attributes.put("complianceNumber", getComplianceNumber());
		attributes.put("contactNumber", getContactNumber());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long complianceId = (Long)attributes.get("complianceId");

		if (complianceId != null) {
			setComplianceId(complianceId);
		}

		String complianceName = (String)attributes.get("complianceName");

		if (complianceName != null) {
			setComplianceName(complianceName);
		}

		String complianceColor = (String)attributes.get("complianceColor");

		if (complianceColor != null) {
			setComplianceColor(complianceColor);
		}

		Long complianceNumber = (Long)attributes.get("complianceNumber");

		if (complianceNumber != null) {
			setComplianceNumber(complianceNumber);
		}

		Long contactNumber = (Long)attributes.get("contactNumber");

		if (contactNumber != null) {
			setContactNumber(contactNumber);
		}
	}

	/**
	 * Returns the compliance color of this compliance.
	 *
	 * @return the compliance color of this compliance
	 */
	@Override
	public String getComplianceColor() {
		return model.getComplianceColor();
	}

	/**
	 * Returns the compliance ID of this compliance.
	 *
	 * @return the compliance ID of this compliance
	 */
	@Override
	public long getComplianceId() {
		return model.getComplianceId();
	}

	/**
	 * Returns the compliance name of this compliance.
	 *
	 * @return the compliance name of this compliance
	 */
	@Override
	public String getComplianceName() {
		return model.getComplianceName();
	}

	/**
	 * Returns the compliance number of this compliance.
	 *
	 * @return the compliance number of this compliance
	 */
	@Override
	public long getComplianceNumber() {
		return model.getComplianceNumber();
	}

	/**
	 * Returns the contact number of this compliance.
	 *
	 * @return the contact number of this compliance
	 */
	@Override
	public long getContactNumber() {
		return model.getContactNumber();
	}

	/**
	 * Returns the primary key of this compliance.
	 *
	 * @return the primary key of this compliance
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the compliance color of this compliance.
	 *
	 * @param complianceColor the compliance color of this compliance
	 */
	@Override
	public void setComplianceColor(String complianceColor) {
		model.setComplianceColor(complianceColor);
	}

	/**
	 * Sets the compliance ID of this compliance.
	 *
	 * @param complianceId the compliance ID of this compliance
	 */
	@Override
	public void setComplianceId(long complianceId) {
		model.setComplianceId(complianceId);
	}

	/**
	 * Sets the compliance name of this compliance.
	 *
	 * @param complianceName the compliance name of this compliance
	 */
	@Override
	public void setComplianceName(String complianceName) {
		model.setComplianceName(complianceName);
	}

	/**
	 * Sets the compliance number of this compliance.
	 *
	 * @param complianceNumber the compliance number of this compliance
	 */
	@Override
	public void setComplianceNumber(long complianceNumber) {
		model.setComplianceNumber(complianceNumber);
	}

	/**
	 * Sets the contact number of this compliance.
	 *
	 * @param contactNumber the contact number of this compliance
	 */
	@Override
	public void setContactNumber(long contactNumber) {
		model.setContactNumber(contactNumber);
	}

	/**
	 * Sets the primary key of this compliance.
	 *
	 * @param primaryKey the primary key of this compliance
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	@Override
	protected ComplianceWrapper wrap(Compliance compliance) {
		return new ComplianceWrapper(compliance);
	}

}