/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package complianceservice.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link complianceservice.service.http.ComplianceServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ComplianceSoap implements Serializable {

	public static ComplianceSoap toSoapModel(Compliance model) {
		ComplianceSoap soapModel = new ComplianceSoap();

		soapModel.setComplianceId(model.getComplianceId());
		soapModel.setComplianceName(model.getComplianceName());
		soapModel.setComplianceColor(model.getComplianceColor());
		soapModel.setComplianceNumber(model.getComplianceNumber());
		soapModel.setContactNumber(model.getContactNumber());

		return soapModel;
	}

	public static ComplianceSoap[] toSoapModels(Compliance[] models) {
		ComplianceSoap[] soapModels = new ComplianceSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ComplianceSoap[][] toSoapModels(Compliance[][] models) {
		ComplianceSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ComplianceSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ComplianceSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ComplianceSoap[] toSoapModels(List<Compliance> models) {
		List<ComplianceSoap> soapModels = new ArrayList<ComplianceSoap>(
			models.size());

		for (Compliance model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ComplianceSoap[soapModels.size()]);
	}

	public ComplianceSoap() {
	}

	public long getPrimaryKey() {
		return _complianceId;
	}

	public void setPrimaryKey(long pk) {
		setComplianceId(pk);
	}

	public long getComplianceId() {
		return _complianceId;
	}

	public void setComplianceId(long complianceId) {
		_complianceId = complianceId;
	}

	public String getComplianceName() {
		return _complianceName;
	}

	public void setComplianceName(String complianceName) {
		_complianceName = complianceName;
	}

	public String getComplianceColor() {
		return _complianceColor;
	}

	public void setComplianceColor(String complianceColor) {
		_complianceColor = complianceColor;
	}

	public long getComplianceNumber() {
		return _complianceNumber;
	}

	public void setComplianceNumber(long complianceNumber) {
		_complianceNumber = complianceNumber;
	}

	public long getContactNumber() {
		return _contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		_contactNumber = contactNumber;
	}

	private long _complianceId;
	private String _complianceName;
	private String _complianceColor;
	private long _complianceNumber;
	private long _contactNumber;

}