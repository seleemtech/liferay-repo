package com.comp.portlet;

import com.comp.constants.CompliancePortletKeys;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import complianceservice.model.Compliance;
import complianceservice.service.ComplianceLocalServiceUtil;

/**
 * @author Vinoth kumar
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Compliance",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + CompliancePortletKeys.COMPLIANCE,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class CompliancePortlet extends MVCPortlet {

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		List<Compliance> complianceList = ComplianceLocalServiceUtil.getCompliances(-1, -1);
		String complianceId = ParamUtil.getString(renderRequest, "complianceId");
		
		renderRequest.setAttribute("complianceId", complianceId);
		if (complianceId != null) {
			Compliance compliance = null;
			try {
				compliance = ComplianceLocalServiceUtil.getCompliance(Long.valueOf(complianceId));
			} catch (NumberFormatException | PortalException e) {
				// TODO: handle exception
			}
			renderRequest.setAttribute("compliance", compliance);
			
		}
		renderRequest.setAttribute("complianceList", complianceList);
		super.render(renderRequest, renderResponse);
	}
	
	@ProcessAction(name = "addCompliance")
	public void addCompliance(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException {
		long complianceId = ParamUtil.getLong(actionRequest, "complianceId");
		String complianceName = ParamUtil.getString(actionRequest, "complianceName");
		String complianceColor = ParamUtil.getString(actionRequest, "complianceColor");
		long complianceNumber = ParamUtil.getLong(actionRequest, "complianceNumber");
		long contactNumber = ParamUtil.getLong(actionRequest, "contactNumber");
		
		Compliance compliance=null;
		if(complianceId > 0) {
			compliance = ComplianceLocalServiceUtil.getCompliance(complianceId);
			compliance.setComplianceId(complianceId);
			compliance.setComplianceName(complianceName);
			compliance.setComplianceColor(complianceColor);
			compliance.setComplianceNumber(complianceNumber);
			compliance.setContactNumber(contactNumber);

			ComplianceLocalServiceUtil.updateCompliance(compliance);
		}
		else {
			
			compliance = ComplianceLocalServiceUtil.createCompliance(complianceId);
			compliance.setComplianceId(complianceId);
			compliance.setComplianceName(complianceName);
			compliance.setComplianceColor(complianceColor);
			compliance.setComplianceNumber(complianceNumber);
			compliance.setContactNumber(contactNumber);

			ComplianceLocalServiceUtil.addCompliance(compliance);
		}
	}
		@ProcessAction(name = "deleteIt")
		public void deleteCompliance(ActionRequest actionRequest, ActionResponse actionResponse) {
			long complianceId = ParamUtil.getLong(actionRequest, "complianceId", GetterUtil.DEFAULT_LONG);
			try {
				ComplianceLocalServiceUtil.deleteCompliance(complianceId);
			} catch (Exception e) {
			}
	}
}