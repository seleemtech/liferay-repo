package com.comp.constants;

/**
 * @author Vinoth kumar
 */
public class CompliancePortletKeys {

	public static final String COMPLIANCE =
		"com_comp_CompliancePortlet";

}