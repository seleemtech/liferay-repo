/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.mobileservice.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Mobile}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Mobile
 * @generated
 */
public class MobileWrapper
	extends BaseModelWrapper<Mobile> implements Mobile, ModelWrapper<Mobile> {

	public MobileWrapper(Mobile mobile) {
		super(mobile);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("mobileId", getMobileId());
		attributes.put("mobileName", getMobileName());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long mobileId = (Long)attributes.get("mobileId");

		if (mobileId != null) {
			setMobileId(mobileId);
		}

		String mobileName = (String)attributes.get("mobileName");

		if (mobileName != null) {
			setMobileName(mobileName);
		}
	}

	/**
	 * Returns the mobile ID of this mobile.
	 *
	 * @return the mobile ID of this mobile
	 */
	@Override
	public long getMobileId() {
		return model.getMobileId();
	}

	/**
	 * Returns the mobile name of this mobile.
	 *
	 * @return the mobile name of this mobile
	 */
	@Override
	public String getMobileName() {
		return model.getMobileName();
	}

	/**
	 * Returns the primary key of this mobile.
	 *
	 * @return the primary key of this mobile
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this mobile.
	 *
	 * @return the uuid of this mobile
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the mobile ID of this mobile.
	 *
	 * @param mobileId the mobile ID of this mobile
	 */
	@Override
	public void setMobileId(long mobileId) {
		model.setMobileId(mobileId);
	}

	/**
	 * Sets the mobile name of this mobile.
	 *
	 * @param mobileName the mobile name of this mobile
	 */
	@Override
	public void setMobileName(String mobileName) {
		model.setMobileName(mobileName);
	}

	/**
	 * Sets the primary key of this mobile.
	 *
	 * @param primaryKey the primary key of this mobile
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this mobile.
	 *
	 * @param uuid the uuid of this mobile
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected MobileWrapper wrap(Mobile mobile) {
		return new MobileWrapper(mobile);
	}

}