/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.mobileservice.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.mobileservice.model.Mobile;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * The persistence utility for the mobile service. This utility wraps <code>com.mobileservice.service.persistence.impl.MobilePersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see MobilePersistence
 * @generated
 */
public class MobileUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(Mobile mobile) {
		getPersistence().clearCache(mobile);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, Mobile> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Mobile> findWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Mobile> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Mobile> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static Mobile update(Mobile mobile) {
		return getPersistence().update(mobile);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static Mobile update(Mobile mobile, ServiceContext serviceContext) {
		return getPersistence().update(mobile, serviceContext);
	}

	/**
	 * Returns all the mobiles where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching mobiles
	 */
	public static List<Mobile> findByUuid(String uuid) {
		return getPersistence().findByUuid(uuid);
	}

	/**
	 * Returns a range of all the mobiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @return the range of matching mobiles
	 */
	public static List<Mobile> findByUuid(String uuid, int start, int end) {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	 * Returns an ordered range of all the mobiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching mobiles
	 */
	public static List<Mobile> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the mobiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching mobiles
	 */
	public static List<Mobile> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<Mobile> orderByComparator, boolean useFinderCache) {

		return getPersistence().findByUuid(
			uuid, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public static Mobile findByUuid_First(
			String uuid, OrderByComparator<Mobile> orderByComparator)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the first mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public static Mobile fetchByUuid_First(
		String uuid, OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the last mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public static Mobile findByUuid_Last(
			String uuid, OrderByComparator<Mobile> orderByComparator)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the last mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public static Mobile fetchByUuid_Last(
		String uuid, OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the mobiles before and after the current mobile in the ordered set where uuid = &#63;.
	 *
	 * @param mobileId the primary key of the current mobile
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next mobile
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public static Mobile[] findByUuid_PrevAndNext(
			long mobileId, String uuid,
			OrderByComparator<Mobile> orderByComparator)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findByUuid_PrevAndNext(
			mobileId, uuid, orderByComparator);
	}

	/**
	 * Removes all the mobiles where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public static void removeByUuid(String uuid) {
		getPersistence().removeByUuid(uuid);
	}

	/**
	 * Returns the number of mobiles where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching mobiles
	 */
	public static int countByUuid(String uuid) {
		return getPersistence().countByUuid(uuid);
	}

	/**
	 * Returns all the mobiles where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @return the matching mobiles
	 */
	public static List<Mobile> findBymobilefind(String mobileName) {
		return getPersistence().findBymobilefind(mobileName);
	}

	/**
	 * Returns a range of all the mobiles where mobileName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param mobileName the mobile name
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @return the range of matching mobiles
	 */
	public static List<Mobile> findBymobilefind(
		String mobileName, int start, int end) {

		return getPersistence().findBymobilefind(mobileName, start, end);
	}

	/**
	 * Returns an ordered range of all the mobiles where mobileName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param mobileName the mobile name
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching mobiles
	 */
	public static List<Mobile> findBymobilefind(
		String mobileName, int start, int end,
		OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().findBymobilefind(
			mobileName, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the mobiles where mobileName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param mobileName the mobile name
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching mobiles
	 */
	public static List<Mobile> findBymobilefind(
		String mobileName, int start, int end,
		OrderByComparator<Mobile> orderByComparator, boolean useFinderCache) {

		return getPersistence().findBymobilefind(
			mobileName, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public static Mobile findBymobilefind_First(
			String mobileName, OrderByComparator<Mobile> orderByComparator)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findBymobilefind_First(
			mobileName, orderByComparator);
	}

	/**
	 * Returns the first mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public static Mobile fetchBymobilefind_First(
		String mobileName, OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().fetchBymobilefind_First(
			mobileName, orderByComparator);
	}

	/**
	 * Returns the last mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public static Mobile findBymobilefind_Last(
			String mobileName, OrderByComparator<Mobile> orderByComparator)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findBymobilefind_Last(
			mobileName, orderByComparator);
	}

	/**
	 * Returns the last mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public static Mobile fetchBymobilefind_Last(
		String mobileName, OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().fetchBymobilefind_Last(
			mobileName, orderByComparator);
	}

	/**
	 * Returns the mobiles before and after the current mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileId the primary key of the current mobile
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next mobile
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public static Mobile[] findBymobilefind_PrevAndNext(
			long mobileId, String mobileName,
			OrderByComparator<Mobile> orderByComparator)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findBymobilefind_PrevAndNext(
			mobileId, mobileName, orderByComparator);
	}

	/**
	 * Removes all the mobiles where mobileName = &#63; from the database.
	 *
	 * @param mobileName the mobile name
	 */
	public static void removeBymobilefind(String mobileName) {
		getPersistence().removeBymobilefind(mobileName);
	}

	/**
	 * Returns the number of mobiles where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @return the number of matching mobiles
	 */
	public static int countBymobilefind(String mobileName) {
		return getPersistence().countBymobilefind(mobileName);
	}

	/**
	 * Caches the mobile in the entity cache if it is enabled.
	 *
	 * @param mobile the mobile
	 */
	public static void cacheResult(Mobile mobile) {
		getPersistence().cacheResult(mobile);
	}

	/**
	 * Caches the mobiles in the entity cache if it is enabled.
	 *
	 * @param mobiles the mobiles
	 */
	public static void cacheResult(List<Mobile> mobiles) {
		getPersistence().cacheResult(mobiles);
	}

	/**
	 * Creates a new mobile with the primary key. Does not add the mobile to the database.
	 *
	 * @param mobileId the primary key for the new mobile
	 * @return the new mobile
	 */
	public static Mobile create(long mobileId) {
		return getPersistence().create(mobileId);
	}

	/**
	 * Removes the mobile with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mobileId the primary key of the mobile
	 * @return the mobile that was removed
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public static Mobile remove(long mobileId)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().remove(mobileId);
	}

	public static Mobile updateImpl(Mobile mobile) {
		return getPersistence().updateImpl(mobile);
	}

	/**
	 * Returns the mobile with the primary key or throws a <code>NoSuchMobileException</code> if it could not be found.
	 *
	 * @param mobileId the primary key of the mobile
	 * @return the mobile
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public static Mobile findByPrimaryKey(long mobileId)
		throws com.mobileservice.exception.NoSuchMobileException {

		return getPersistence().findByPrimaryKey(mobileId);
	}

	/**
	 * Returns the mobile with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param mobileId the primary key of the mobile
	 * @return the mobile, or <code>null</code> if a mobile with the primary key could not be found
	 */
	public static Mobile fetchByPrimaryKey(long mobileId) {
		return getPersistence().fetchByPrimaryKey(mobileId);
	}

	/**
	 * Returns all the mobiles.
	 *
	 * @return the mobiles
	 */
	public static List<Mobile> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the mobiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @return the range of mobiles
	 */
	public static List<Mobile> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the mobiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of mobiles
	 */
	public static List<Mobile> findAll(
		int start, int end, OrderByComparator<Mobile> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the mobiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of mobiles
	 */
	public static List<Mobile> findAll(
		int start, int end, OrderByComparator<Mobile> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the mobiles from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of mobiles.
	 *
	 * @return the number of mobiles
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static MobilePersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<MobilePersistence, MobilePersistence>
		_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(MobilePersistence.class);

		ServiceTracker<MobilePersistence, MobilePersistence> serviceTracker =
			new ServiceTracker<MobilePersistence, MobilePersistence>(
				bundle.getBundleContext(), MobilePersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}