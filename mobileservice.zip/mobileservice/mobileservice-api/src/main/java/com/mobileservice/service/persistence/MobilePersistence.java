/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.mobileservice.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.mobileservice.exception.NoSuchMobileException;
import com.mobileservice.model.Mobile;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the mobile service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see MobileUtil
 * @generated
 */
@ProviderType
public interface MobilePersistence extends BasePersistence<Mobile> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link MobileUtil} to access the mobile persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the mobiles where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching mobiles
	 */
	public java.util.List<Mobile> findByUuid(String uuid);

	/**
	 * Returns a range of all the mobiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @return the range of matching mobiles
	 */
	public java.util.List<Mobile> findByUuid(String uuid, int start, int end);

	/**
	 * Returns an ordered range of all the mobiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching mobiles
	 */
	public java.util.List<Mobile> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns an ordered range of all the mobiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching mobiles
	 */
	public java.util.List<Mobile> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public Mobile findByUuid_First(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<Mobile>
				orderByComparator)
		throws NoSuchMobileException;

	/**
	 * Returns the first mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public Mobile fetchByUuid_First(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns the last mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public Mobile findByUuid_Last(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<Mobile>
				orderByComparator)
		throws NoSuchMobileException;

	/**
	 * Returns the last mobile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public Mobile fetchByUuid_Last(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns the mobiles before and after the current mobile in the ordered set where uuid = &#63;.
	 *
	 * @param mobileId the primary key of the current mobile
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next mobile
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public Mobile[] findByUuid_PrevAndNext(
			long mobileId, String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<Mobile>
				orderByComparator)
		throws NoSuchMobileException;

	/**
	 * Removes all the mobiles where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public void removeByUuid(String uuid);

	/**
	 * Returns the number of mobiles where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching mobiles
	 */
	public int countByUuid(String uuid);

	/**
	 * Returns all the mobiles where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @return the matching mobiles
	 */
	public java.util.List<Mobile> findBymobilefind(String mobileName);

	/**
	 * Returns a range of all the mobiles where mobileName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param mobileName the mobile name
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @return the range of matching mobiles
	 */
	public java.util.List<Mobile> findBymobilefind(
		String mobileName, int start, int end);

	/**
	 * Returns an ordered range of all the mobiles where mobileName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param mobileName the mobile name
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching mobiles
	 */
	public java.util.List<Mobile> findBymobilefind(
		String mobileName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns an ordered range of all the mobiles where mobileName = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param mobileName the mobile name
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching mobiles
	 */
	public java.util.List<Mobile> findBymobilefind(
		String mobileName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public Mobile findBymobilefind_First(
			String mobileName,
			com.liferay.portal.kernel.util.OrderByComparator<Mobile>
				orderByComparator)
		throws NoSuchMobileException;

	/**
	 * Returns the first mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public Mobile fetchBymobilefind_First(
		String mobileName,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns the last mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile
	 * @throws NoSuchMobileException if a matching mobile could not be found
	 */
	public Mobile findBymobilefind_Last(
			String mobileName,
			com.liferay.portal.kernel.util.OrderByComparator<Mobile>
				orderByComparator)
		throws NoSuchMobileException;

	/**
	 * Returns the last mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching mobile, or <code>null</code> if a matching mobile could not be found
	 */
	public Mobile fetchBymobilefind_Last(
		String mobileName,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns the mobiles before and after the current mobile in the ordered set where mobileName = &#63;.
	 *
	 * @param mobileId the primary key of the current mobile
	 * @param mobileName the mobile name
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next mobile
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public Mobile[] findBymobilefind_PrevAndNext(
			long mobileId, String mobileName,
			com.liferay.portal.kernel.util.OrderByComparator<Mobile>
				orderByComparator)
		throws NoSuchMobileException;

	/**
	 * Removes all the mobiles where mobileName = &#63; from the database.
	 *
	 * @param mobileName the mobile name
	 */
	public void removeBymobilefind(String mobileName);

	/**
	 * Returns the number of mobiles where mobileName = &#63;.
	 *
	 * @param mobileName the mobile name
	 * @return the number of matching mobiles
	 */
	public int countBymobilefind(String mobileName);

	/**
	 * Caches the mobile in the entity cache if it is enabled.
	 *
	 * @param mobile the mobile
	 */
	public void cacheResult(Mobile mobile);

	/**
	 * Caches the mobiles in the entity cache if it is enabled.
	 *
	 * @param mobiles the mobiles
	 */
	public void cacheResult(java.util.List<Mobile> mobiles);

	/**
	 * Creates a new mobile with the primary key. Does not add the mobile to the database.
	 *
	 * @param mobileId the primary key for the new mobile
	 * @return the new mobile
	 */
	public Mobile create(long mobileId);

	/**
	 * Removes the mobile with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param mobileId the primary key of the mobile
	 * @return the mobile that was removed
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public Mobile remove(long mobileId) throws NoSuchMobileException;

	public Mobile updateImpl(Mobile mobile);

	/**
	 * Returns the mobile with the primary key or throws a <code>NoSuchMobileException</code> if it could not be found.
	 *
	 * @param mobileId the primary key of the mobile
	 * @return the mobile
	 * @throws NoSuchMobileException if a mobile with the primary key could not be found
	 */
	public Mobile findByPrimaryKey(long mobileId) throws NoSuchMobileException;

	/**
	 * Returns the mobile with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param mobileId the primary key of the mobile
	 * @return the mobile, or <code>null</code> if a mobile with the primary key could not be found
	 */
	public Mobile fetchByPrimaryKey(long mobileId);

	/**
	 * Returns all the mobiles.
	 *
	 * @return the mobiles
	 */
	public java.util.List<Mobile> findAll();

	/**
	 * Returns a range of all the mobiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @return the range of mobiles
	 */
	public java.util.List<Mobile> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the mobiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of mobiles
	 */
	public java.util.List<Mobile> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator);

	/**
	 * Returns an ordered range of all the mobiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>MobileModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of mobiles
	 * @param end the upper bound of the range of mobiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of mobiles
	 */
	public java.util.List<Mobile> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Mobile>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the mobiles from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of mobiles.
	 *
	 * @return the number of mobiles
	 */
	public int countAll();

}