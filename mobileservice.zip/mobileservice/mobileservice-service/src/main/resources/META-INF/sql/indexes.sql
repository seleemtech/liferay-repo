create index IX_AF964B82 on FOO_Mobile (mobileName[$COLUMN_LENGTH:75$]);
create index IX_DB5F9313 on FOO_Mobile (uuid_[$COLUMN_LENGTH:75$]);