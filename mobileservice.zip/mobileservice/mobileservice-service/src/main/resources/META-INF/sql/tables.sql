create table FOO_Mobile (
	uuid_ VARCHAR(75) null,
	mobileId LONG not null primary key,
	mobileName VARCHAR(75) null
);