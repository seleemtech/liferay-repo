package com.children.constants;

/**
 * @author DELL
 */
public class ChildrenPortletKeys {

	public static final String CHILDREN =
		"com_children_ChildrenPortlet";

}