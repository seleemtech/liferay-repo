package com.children.portlet;

import com.children.constants.ChildrenPortletKeys;
import com.childrenservice.model.Children;
import com.childrenservice.service.ChildrenLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author DELL
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Children", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp", "javax.portlet.name=" + ChildrenPortletKeys.CHILDREN,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class ChildrenPortlet extends MVCPortlet {
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		List<Children> clist = ChildrenLocalServiceUtil.getChildrens(-1, -1);

		long childrenId = ParamUtil.getLong(renderRequest, "childrenId");
		renderRequest.setAttribute("childrenId", childrenId);
		if (childrenId > 0) {
			Children children = null;
			try {
				children = ChildrenLocalServiceUtil.getChildren(childrenId);
			} catch (Exception e) {
				// TODO: handle exception
			}
			renderRequest.setAttribute("children", children);

		}
		renderRequest.setAttribute("clist", clist);
		// TODO Auto-generated method stub
		super.render(renderRequest, renderResponse);
	}

	@ProcessAction(name = "addchildren")
	public void addchildren(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException {
		System.out.println("asbs");
		long childrenId = ParamUtil.getLong(actionRequest, "childrenId");
		String childrenName = ParamUtil.getString(actionRequest, "childrenName");
		long childrenNo = ParamUtil.getLong(actionRequest, "childrenNo");
		String childrenAdd = ParamUtil.getString(actionRequest, "childrenAdd");

		if (childrenId > 0) {
			Children children = null;
			children = ChildrenLocalServiceUtil.getChildren(childrenId);
			children.setChildrenId(childrenId);
			children.setChildrenName(childrenName);
			children.setChildrenNo(childrenNo);
			children.setChildrenAdd(childrenAdd);
			ChildrenLocalServiceUtil.updateChildren(children);
			System.out.println("this is updatinga");
		} else {
			Children children = null;
			children = ChildrenLocalServiceUtil.createChildren(childrenId);
			children.setChildrenId(childrenId);
			children.setChildrenName(childrenName);
			children.setChildrenNo(childrenNo);
			children.setChildrenAdd(childrenAdd);
			ChildrenLocalServiceUtil.addChildren(children);
			System.out.println("this is add");

		}
	}

	@ProcessAction(name = "delete")
	public void delete(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException {
		long childrenId = ParamUtil.getLong(actionRequest, "childrenId");
		ChildrenLocalServiceUtil.deleteChildren(childrenId);
	}
}
