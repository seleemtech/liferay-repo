/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.childrenservice.service.persistence;

import com.childrenservice.exception.NoSuchChildrenException;
import com.childrenservice.model.Children;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the children service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ChildrenUtil
 * @generated
 */
@ProviderType
public interface ChildrenPersistence extends BasePersistence<Children> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link ChildrenUtil} to access the children persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the childrens where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching childrens
	 */
	public java.util.List<Children> findByUuid(String uuid);

	/**
	 * Returns a range of all the childrens where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ChildrenModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of childrens
	 * @param end the upper bound of the range of childrens (not inclusive)
	 * @return the range of matching childrens
	 */
	public java.util.List<Children> findByUuid(String uuid, int start, int end);

	/**
	 * Returns an ordered range of all the childrens where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ChildrenModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of childrens
	 * @param end the upper bound of the range of childrens (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching childrens
	 */
	public java.util.List<Children> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Children>
			orderByComparator);

	/**
	 * Returns an ordered range of all the childrens where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ChildrenModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of childrens
	 * @param end the upper bound of the range of childrens (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching childrens
	 */
	public java.util.List<Children> findByUuid(
		String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Children>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first children in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching children
	 * @throws NoSuchChildrenException if a matching children could not be found
	 */
	public Children findByUuid_First(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<Children>
				orderByComparator)
		throws NoSuchChildrenException;

	/**
	 * Returns the first children in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching children, or <code>null</code> if a matching children could not be found
	 */
	public Children fetchByUuid_First(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Children>
			orderByComparator);

	/**
	 * Returns the last children in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching children
	 * @throws NoSuchChildrenException if a matching children could not be found
	 */
	public Children findByUuid_Last(
			String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<Children>
				orderByComparator)
		throws NoSuchChildrenException;

	/**
	 * Returns the last children in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching children, or <code>null</code> if a matching children could not be found
	 */
	public Children fetchByUuid_Last(
		String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<Children>
			orderByComparator);

	/**
	 * Returns the childrens before and after the current children in the ordered set where uuid = &#63;.
	 *
	 * @param childrenId the primary key of the current children
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next children
	 * @throws NoSuchChildrenException if a children with the primary key could not be found
	 */
	public Children[] findByUuid_PrevAndNext(
			long childrenId, String uuid,
			com.liferay.portal.kernel.util.OrderByComparator<Children>
				orderByComparator)
		throws NoSuchChildrenException;

	/**
	 * Removes all the childrens where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public void removeByUuid(String uuid);

	/**
	 * Returns the number of childrens where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching childrens
	 */
	public int countByUuid(String uuid);

	/**
	 * Caches the children in the entity cache if it is enabled.
	 *
	 * @param children the children
	 */
	public void cacheResult(Children children);

	/**
	 * Caches the childrens in the entity cache if it is enabled.
	 *
	 * @param childrens the childrens
	 */
	public void cacheResult(java.util.List<Children> childrens);

	/**
	 * Creates a new children with the primary key. Does not add the children to the database.
	 *
	 * @param childrenId the primary key for the new children
	 * @return the new children
	 */
	public Children create(long childrenId);

	/**
	 * Removes the children with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param childrenId the primary key of the children
	 * @return the children that was removed
	 * @throws NoSuchChildrenException if a children with the primary key could not be found
	 */
	public Children remove(long childrenId) throws NoSuchChildrenException;

	public Children updateImpl(Children children);

	/**
	 * Returns the children with the primary key or throws a <code>NoSuchChildrenException</code> if it could not be found.
	 *
	 * @param childrenId the primary key of the children
	 * @return the children
	 * @throws NoSuchChildrenException if a children with the primary key could not be found
	 */
	public Children findByPrimaryKey(long childrenId)
		throws NoSuchChildrenException;

	/**
	 * Returns the children with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param childrenId the primary key of the children
	 * @return the children, or <code>null</code> if a children with the primary key could not be found
	 */
	public Children fetchByPrimaryKey(long childrenId);

	/**
	 * Returns all the childrens.
	 *
	 * @return the childrens
	 */
	public java.util.List<Children> findAll();

	/**
	 * Returns a range of all the childrens.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ChildrenModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of childrens
	 * @param end the upper bound of the range of childrens (not inclusive)
	 * @return the range of childrens
	 */
	public java.util.List<Children> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the childrens.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ChildrenModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of childrens
	 * @param end the upper bound of the range of childrens (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of childrens
	 */
	public java.util.List<Children> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Children>
			orderByComparator);

	/**
	 * Returns an ordered range of all the childrens.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ChildrenModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of childrens
	 * @param end the upper bound of the range of childrens (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of childrens
	 */
	public java.util.List<Children> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<Children>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the childrens from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of childrens.
	 *
	 * @return the number of childrens
	 */
	public int countAll();

}