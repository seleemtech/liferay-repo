/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.childrenservice.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.childrenservice.service.http.ChildrenServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ChildrenSoap implements Serializable {

	public static ChildrenSoap toSoapModel(Children model) {
		ChildrenSoap soapModel = new ChildrenSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setChildrenId(model.getChildrenId());
		soapModel.setChildrenName(model.getChildrenName());
		soapModel.setChildrenNo(model.getChildrenNo());
		soapModel.setChildrenAdd(model.getChildrenAdd());

		return soapModel;
	}

	public static ChildrenSoap[] toSoapModels(Children[] models) {
		ChildrenSoap[] soapModels = new ChildrenSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ChildrenSoap[][] toSoapModels(Children[][] models) {
		ChildrenSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ChildrenSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ChildrenSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ChildrenSoap[] toSoapModels(List<Children> models) {
		List<ChildrenSoap> soapModels = new ArrayList<ChildrenSoap>(
			models.size());

		for (Children model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ChildrenSoap[soapModels.size()]);
	}

	public ChildrenSoap() {
	}

	public long getPrimaryKey() {
		return _childrenId;
	}

	public void setPrimaryKey(long pk) {
		setChildrenId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getChildrenId() {
		return _childrenId;
	}

	public void setChildrenId(long childrenId) {
		_childrenId = childrenId;
	}

	public String getChildrenName() {
		return _childrenName;
	}

	public void setChildrenName(String childrenName) {
		_childrenName = childrenName;
	}

	public long getChildrenNo() {
		return _childrenNo;
	}

	public void setChildrenNo(long childrenNo) {
		_childrenNo = childrenNo;
	}

	public String getChildrenAdd() {
		return _childrenAdd;
	}

	public void setChildrenAdd(String childrenAdd) {
		_childrenAdd = childrenAdd;
	}

	private String _uuid;
	private long _childrenId;
	private String _childrenName;
	private long _childrenNo;
	private String _childrenAdd;

}