/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.childrenservice.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Children}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Children
 * @generated
 */
public class ChildrenWrapper
	extends BaseModelWrapper<Children>
	implements Children, ModelWrapper<Children> {

	public ChildrenWrapper(Children children) {
		super(children);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("childrenId", getChildrenId());
		attributes.put("childrenName", getChildrenName());
		attributes.put("childrenNo", getChildrenNo());
		attributes.put("childrenAdd", getChildrenAdd());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long childrenId = (Long)attributes.get("childrenId");

		if (childrenId != null) {
			setChildrenId(childrenId);
		}

		String childrenName = (String)attributes.get("childrenName");

		if (childrenName != null) {
			setChildrenName(childrenName);
		}

		Long childrenNo = (Long)attributes.get("childrenNo");

		if (childrenNo != null) {
			setChildrenNo(childrenNo);
		}

		String childrenAdd = (String)attributes.get("childrenAdd");

		if (childrenAdd != null) {
			setChildrenAdd(childrenAdd);
		}
	}

	/**
	 * Returns the children add of this children.
	 *
	 * @return the children add of this children
	 */
	@Override
	public String getChildrenAdd() {
		return model.getChildrenAdd();
	}

	/**
	 * Returns the children ID of this children.
	 *
	 * @return the children ID of this children
	 */
	@Override
	public long getChildrenId() {
		return model.getChildrenId();
	}

	/**
	 * Returns the children name of this children.
	 *
	 * @return the children name of this children
	 */
	@Override
	public String getChildrenName() {
		return model.getChildrenName();
	}

	/**
	 * Returns the children no of this children.
	 *
	 * @return the children no of this children
	 */
	@Override
	public long getChildrenNo() {
		return model.getChildrenNo();
	}

	/**
	 * Returns the primary key of this children.
	 *
	 * @return the primary key of this children
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this children.
	 *
	 * @return the uuid of this children
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the children add of this children.
	 *
	 * @param childrenAdd the children add of this children
	 */
	@Override
	public void setChildrenAdd(String childrenAdd) {
		model.setChildrenAdd(childrenAdd);
	}

	/**
	 * Sets the children ID of this children.
	 *
	 * @param childrenId the children ID of this children
	 */
	@Override
	public void setChildrenId(long childrenId) {
		model.setChildrenId(childrenId);
	}

	/**
	 * Sets the children name of this children.
	 *
	 * @param childrenName the children name of this children
	 */
	@Override
	public void setChildrenName(String childrenName) {
		model.setChildrenName(childrenName);
	}

	/**
	 * Sets the children no of this children.
	 *
	 * @param childrenNo the children no of this children
	 */
	@Override
	public void setChildrenNo(long childrenNo) {
		model.setChildrenNo(childrenNo);
	}

	/**
	 * Sets the primary key of this children.
	 *
	 * @param primaryKey the primary key of this children
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this children.
	 *
	 * @param uuid the uuid of this children
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected ChildrenWrapper wrap(Children children) {
		return new ChildrenWrapper(children);
	}

}