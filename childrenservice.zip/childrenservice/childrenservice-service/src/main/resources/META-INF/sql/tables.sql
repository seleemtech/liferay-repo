create table FOO_Children (
	uuid_ VARCHAR(75) null,
	childrenId LONG not null primary key,
	childrenName VARCHAR(75) null,
	childrenNo LONG,
	childrenAdd VARCHAR(75) null
);