/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.childrenservice.model.impl;

import com.childrenservice.model.Children;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Children in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ChildrenCacheModel
	implements CacheModel<Children>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ChildrenCacheModel)) {
			return false;
		}

		ChildrenCacheModel childrenCacheModel = (ChildrenCacheModel)object;

		if (childrenId == childrenCacheModel.childrenId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, childrenId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", childrenId=");
		sb.append(childrenId);
		sb.append(", childrenName=");
		sb.append(childrenName);
		sb.append(", childrenNo=");
		sb.append(childrenNo);
		sb.append(", childrenAdd=");
		sb.append(childrenAdd);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Children toEntityModel() {
		ChildrenImpl childrenImpl = new ChildrenImpl();

		if (uuid == null) {
			childrenImpl.setUuid("");
		}
		else {
			childrenImpl.setUuid(uuid);
		}

		childrenImpl.setChildrenId(childrenId);

		if (childrenName == null) {
			childrenImpl.setChildrenName("");
		}
		else {
			childrenImpl.setChildrenName(childrenName);
		}

		childrenImpl.setChildrenNo(childrenNo);

		if (childrenAdd == null) {
			childrenImpl.setChildrenAdd("");
		}
		else {
			childrenImpl.setChildrenAdd(childrenAdd);
		}

		childrenImpl.resetOriginalValues();

		return childrenImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		childrenId = objectInput.readLong();
		childrenName = objectInput.readUTF();

		childrenNo = objectInput.readLong();
		childrenAdd = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(childrenId);

		if (childrenName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(childrenName);
		}

		objectOutput.writeLong(childrenNo);

		if (childrenAdd == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(childrenAdd);
		}
	}

	public String uuid;
	public long childrenId;
	public String childrenName;
	public long childrenNo;
	public String childrenAdd;

}